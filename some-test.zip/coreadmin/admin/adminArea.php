<?php
@session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$menuObj = new Menu();
$menuObj->checkPermission();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

    <head>
        <?= headcontent() ?>
        <script src="js/functions.js"></script>
    </head>
    <body>
        <?php include('includes/header.php'); ?>
        <section id="content">
            <div class="g12 nodrop">
                <h1>Welcome</h1>
                <p>
                    to admin panel of
                    <?= __SITENAME__ ?>
                </p>
                <p>
                    <?php echo $_SESSION['SESS_MSG'];
                    unset($_SESSION['SESS_MSG']);
                    ?>
                </p>
                <form name="ecartFrm" method="post" action="">
                    <?php
                    //echo $commitObj->valDetail(0);
                    //echo '<hr width="100%" />';
                    ?>
                </form>
            </div>
        </section>
        <footer> <?= stripslashes('&copy;copyright by ' . __SITENAME__) ?></footer>
        <div id="nav-under-bg">
            <!-- -->
        </div>
    </body>
</html>
