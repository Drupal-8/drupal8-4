<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
require_once('validation_class.php');

$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$tempObj = new Template();
$layObj = new Layout();
if (isset($_POST['submit'])) {  //print_r($_POST);print_r($_FILES);die;
    $arr_error = $layObj->validationforUploadLayout($_POST, $_FILES);
    //print_r($arr_error);die;
    if ($arr_error['ERROR']) {
        $layObj->uploadLayoutFile($_POST, $_FILES);
    }
}
echo headcontent();
?>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Layout</h1>
        <fieldset>

            <form name="frmUser" id="frmUser" method="post" enctype="multipart/form-data">

                <fieldset>
                    <label>Upload Layout</label>

                    <?php echo $_SESSION['SESS_MSG'] ?>
                    <?php unset($_SESSION['SESS_MSG']) ?>

                    <section> <label for="templateName">Select Template</label>
                        <div>
                            <?php echo $tempObj->getAllTemplates($_POST['template']); ?>
                            <div id="chk_templateName"><?php echo $arr_error['template']; ?></div>
                        </div>
                    </section>
                    <section> <label for="Layouts">Select Layout</label>
                        <div>
                            <div id="layoutsssss"><?php echo $tempObj->getRelatedlayouts($_POST['template'],$_POST['layouts']); ?></div>
                            <div id="chk_templateName"><?php echo $arr_error['layouts']; ?></div>
                        </div>
                    </section>
                </fieldset>
                <fieldset>
                    <label>Upload template Images</label>
                    <section> <label for="file">Template Images</label>
                        <div>
                            <input type="file" name="image[]" id="image" multiple />
                            <div id="chk_file"><?php echo $arr_error['image']; ?></div>
                        </div>
                    </section>
                </fieldset>
                <fieldset id='appaend'>
                    <label>Upload HTML Section</label>
                    <label>Upload header</label>
                    <section> <label for="file">Header Section</label>
                        <div>
                            <input type="file" name="headerFile" id="image"  />
                            <div id="chk_file"><?php echo $arr_error['headerFile']; ?></div>
                        </div>
                    </section>
                    <section> <label for="file">Header Image</label>
                        <div>
                            <input type="file" name="headerImage" id="image"  />
                            <div id="chk_file"><?php echo $arr_error['headerImage']; ?></div>
                        </div>
                    </section>
                    <section> <label for="file">Header Height</label>
                        <div>
                            <input type="text" name="headerHeight" id="heigh" value="<?php echo $_POST['headerHeight']; ?>" />
                            <div id="chk_file"><?php echo $arr_error['headerHeight']; ?></div>
                        </div>
                    </section>
                    <!--///////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->
                    <fieldset id='appaend-html'>
                        <label>Upload html Section(1)</label>

                        <section> <label for="file_1">Html Section</label>
                            <div>
                                <input type="file" name="htmlSecFile[]" id="htmlSec_1"  />
                                <div id="chk_file"></div>
                            </div>
                        </section>
                        <section> <label for="file_1">Html Thumb Image</label>
                            <div>
                                <input type="file" name="htmlSecThumb[]" id="htmlThumb_1"/>
                                <div id="chk_file"></div>
                            </div>
                        </section>
                        <section> <label for="file_1">Header Height</label>
                            <div>
                                <input type="text" name="htmlSecHeight[]" id="heigh_1" />
                                <div id="chk_file"></div>
                            </div>
                        </section>
                    </fieldset>
                    <!--     ///////////////////////////////////////////////////////////////////////////////////////////////               -->
                </fieldset>
                <section> 
                    <div>
                        <button type="button" name="addlayout" id="addlayout">Add More Layout</button>
                        <div id="chk_layout"></div>
                    </div>
                </section>
                <section>
                    <div style="width: 100%;text-align: center;">
                        <button type="submit" name="submit">Submit</button>
                        <!--<button type="button" name="back" onClick="hrefBack()" id="back">Back</button>-->
                    </div>
                </section>
            </form>
        </fieldset>
    </section>

    <script>

        var i = 2;
        $("#addlayout").click(function() { //alert('ggg');

            $("#appaend-html").append('<label id="lbl_' + i + '">Upload html Section(' + i + ')</label><section id="sec1_' + i + '"> <label for="file_' + i + '" >Html Section</label><div><input type="file" name="htmlSecFile[]" id="htmlSec_' + i + '"  /><div id="chk_file_' + i + '"></div></div></section><section id="sec2_' + i + '"> <label for="file_' + i + '" >Html Thumb Image</label><div><input type="file" name="htmlSecThumb[]" id="htmlThumb_' + i + '"/><div id="chk_file_' + i + '"></div></div></section><section id="sec3_' + i + '"> <label for="file_' + i + '" >Header Height</label><div><input type="text" name="htmlSecHeight[]" id="heigh_' + i + '" /><div id="chk_file_' + i + '"></div></div></section><section id="sec4_' + i + '"><img src="cross.jpeg" height=15 width=15 id="cross_' + i + '" onclick="deleteLayout(' + i + ')" ></section>');

            i++;
        });


        $("#layouts").change(function() {

            var v = $(this).val(); // alert(v);
            $.ajax({
                url: 'getLayouts.php',
                type: 'GET',
                data: {
                    id: v},
                success: function(x) {
                    $("#layoutsssss").html(x);
                }
            });
        });

        function deleteLayout(n) {
            $('#sec1_' + n).remove();
            $('#sec2_' + n).remove();
            $('#sec3_' + n).remove();
            $('#sec4_' + n).remove();
            $('#lbl_' + n).remove();
            i--;
        }

    </script>




