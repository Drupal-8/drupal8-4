<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
require_once('validation_class.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$tempObj = new Template();
if (isset($_POST['submit'])) {  //print_r($_POST);die;
    
    $arr_error = $tempObj->validationforlanding($_POST,$_FILES);
    //print_r($arr_error);die;
    if ($arr_error['ERROR']) {
        $tempObj->uploadTemplateFile($_POST,$_FILES);
    }
    
}
echo headcontent();
?>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Upload landing</h1>
        <fieldset>

            <form name="frmUser" id="frmUser" method="post" enctype="multipart/form-data">
                
                    <fieldset>
                        <label>Upload File/Folder</label>
                        
                        <?php echo $_SESSION['SESS_MSG'] ?>
                        <?php unset($_SESSION['SESS_MSG']) ?>

                        <section> <label for="templateName">Select Template</label>
                            <div>
                                <?php echo $tempObj->getAllTemplates($_POST['template']);;?>
                                <div id="chk_templateName"><?php echo $arr_error['template']; ?></div>
                            </div>
                        </section>

                        <section> <label for="image">Upload Images</label>
                            <div>
                                <input type="file" name="image[]" id="image" multiple />
                                <div id="chk_file"><?php echo $arr_error['image']; ?></div>
                            </div>
                        </section>
                        <section> <label for="js">Upload Javascript Files</label>
                            <div>
                                <input type="file" name="js[]" id="js" multiple />
                                <div id="chk_file"><?php echo $arr_error['js']; ?></div>
                            </div>
                        </section>
                        <section> <label for="css">Upload CSS Files</label>
                            <div>
                                <input type="file" name="css[]" id="css" multiple />
                                <div id="chk_file"><?php echo $arr_error['css']; ?></div>
                            </div>
                        </section>
                        <section> <label for="htmls">Upload Html Files</label>
                            <div>
                                <input type="file" name="htmls[]" id="htmls" multiple />
                                <div id="chk_file"><?php echo $arr_error['htmls']; ?></div>
                            </div>
                        </section>
                    </fieldset>
                    <section>
                        <div style="width: 100%;text-align: center;">
                            <button type="submit" name="submit">Submit</button>
                            <!--<button type="button" name="back" onClick="hrefBack()" id="back">Back</button>-->
                        </div>
                    </section>
            </form>
        </fieldset>
    </section>






