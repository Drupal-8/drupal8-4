<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$id = $_GET['id'];
$fileObj = new EditFiles();
if ($_POST["submit_check"]) {

    $fileObj->Write($_POST["submit_check"],$_FILES);
    
}

echo headcontent();
?>
</head>
<body>
    <?php include('includes/header.php'); ?>



    <section id="content">
        <h1>File</h1>
        <fieldset>
            <form  method="post" enctype="multipart/form-data">
                <fieldset>
                    <label>Edit File</label>
                    <?php echo $_SESSION['SESS_MSG'] ?>
                    <?php unset($_SESSION['SESS_MSG']) ?>
                    <section>
                        <textarea name="tekst" style="height: 500px;width: 923px"><?php $fileObj->Read($id); ?></textarea>
                        <input type="hidden" name="submit_check" value="<?php echo $id; ?>">
                    </section>
                    <section> <label for="image">Upload Images</label>
                        <div>
                            <input type="file" name="image[]" id="image" multiple />
                            <div id="chk_file"><?php echo $arr_error['image']; ?></div>
                        </div>
                    </section>
                </fieldset>
                <section>
                    <div style="width: 100%;text-align: center;">
                        <button type="submit" name="submit">Update page</button>
                        <button type="button" name="back" onClick="hrefBack()" id="back">Back</button>
                    </div>
                </section>
            </form>
        </fieldset>
        <script>
            function hrefBack() {
                history.go(-1);
            }

        </script>
