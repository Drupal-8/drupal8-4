<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php'); 
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$menuObj = new Menu();
$menuObj->checkPermission("manageTemplates.php");
$tempObj = new Template();
?>
<?php echo headcontent()// DOCTYPE,ContentType,Title,style.css,jquery.min.js,jquery-ui.min.js,jquery_ajax.js,ajax.js, Top Pageoptions  ?>

<SCRIPT src="js/common.js" language="javascript" type="text/javascript"></SCRIPT>
<!--				Light Box Starts			-->
<link rel="stylesheet" type="text/css" href="lightbox/doc/css/style.css">
<script type="text/javascript" src="lightbox/src/adapter/shadowbox-base.js"></script>
<script type="text/javascript" src="lightbox/src/shadowbox.js"></script>
<script type="text/javascript">
    Shadowbox.loadSkin('classic', 'lightbox/src/skin');
    Shadowbox.loadLanguage('en', 'lightbox/src/lang');
    Shadowbox.loadPlayer(['flv', 'html', 'iframe', 'img', 'qt', 'swf', 'wmp'], 'lightbox/src/player');
    window.onload = function() {
        Shadowbox.init();
    };
</script>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Manage Templates<?php //if($menuObj->checkAddPermission()) { ?><a class="btn small fr" href="addtemplate.php">Add New Template</a><?php //} ?></h1>
        
                
                <table class="documentation">
                    <tr>
                    <thead>
                    <th>SL.No</th>
                    <th>Tamplate Name</th>
                    <th>Edit Landing Page</th>
                    <th>Edit Template</th>
                    <th>Delete Template</th>
                    </thead>
                    </tr>	 
                    <?php echo $tempObj->allTemplateDetailsInformation($id); ?>
                </table>
            </form>
        </fieldset>
    </section>
</body>
</html>