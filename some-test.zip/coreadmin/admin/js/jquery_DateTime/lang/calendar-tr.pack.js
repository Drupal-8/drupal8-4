/*
 * Turkish Translation by Nuri AKMAN
//	Location: Ankara/TURKEY
//	e-mail	: nuriakman@hotmail.com
//	Date	: April, 9 2003
//
//	Note: if Turkish Characters does not shown on you screen
//		  please include falowing line your html code:
//
//		  <meta http-equiv="Content-Type" content="text/html; charset=windows-1254">
//
*/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('0.1m=9 o("6","h","w�","�1k�15","N�G","E","z","6");0.v=9 o("t","�1i","17","14","11�s","I","F","A�D","B�l","x","u�m","q�k");0.1={};0.1["1f"]="16�n 13 g�n�n� 10�r";0.1["M"]="�8 Y�l (5� i�2 4�l� 3)";0.1["C"]="�8 p (5� i�2 4�l� 3)";0.1["L"]="b�n\'e O";0.1["P"]="a p (5� i�2 4�l� 3)";0.1["R"]="a Y�l (5� i�2 4�l� 3)";0.1["S"]="T U�V";0.1["W"]="X��Z i�2 s�r�1h";0.1["1g"]=" (1e�n)";0.1["1a"]="c h g�n�j 7�f�n";0.1["18"]="c 6 g�n�j 7�f�n";0.1["19"]="12";0.1["1b"]="b�n";0.1["1c"]="1d-Q-y";0.1["K"]="d J y, 1j";0.1["H"]="1l";',62,85,'Calendar|_TT|in|tutunuz|bas|Men|Pazar|ba|nceki|new|Sonraki|Bug|Takvim|||las||Pazartesi||nden|||||Array|Ay|Aral|||Ocak|Kas|_MN|Sal|Ekim||Cumartesi||Eyl|PREV_MONTH|ustos|Cuma|Temmuz|embe|WK|Haziran|MM|TT_DATE_FORMAT|GO_TODAY|PREV_YEAR|Per|git|NEXT_MONTH|mm|NEXT_YEAR|SEL_DATE|Tarih|se|iniz|DRAG_TO_MOVE|Ta||mak|kayd|May|Kapat|ilk|Nisan|amba|Haftan|Mart|SUN_FIRST|CLOSE|MON_FIRST|TODAY|DEF_DATE_FORMAT|dd|bug|TOGGLE|PART_TODAY|kleyiniz|ubat|DD|ar|Hafta|_DN'.split('|'),0,{}))