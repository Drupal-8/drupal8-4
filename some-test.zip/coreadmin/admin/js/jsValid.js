$(document).ready(function() {
                 
                var templateName = $("#templateName");
                var offlineCode = $("#offlineCode");
                var onlineCode = $("#onlineCode");
                var layout_1 = $("#layout_1");
                
               //alert("hello hi");

                templateName.keyup(validateTemplateName);
                templateName.blur(validateTemplateName);
//                
                offlineCode.keyup(validateOfflineCode);
                offlineCode.blur(validateOfflineCode);
//                
                onlineCode.keyup(validateOnlineCode);
                onlineCode.blur(validateOnlineCode);
                
                layout_1.keyup(validatelayout_1);
                layout_1.blur(validatelayout_1);
                

           function validateTemplateName()
             {
                
                       var f = name.val();
                       var filter = /^([A-Za-z ]+)$/;
                               if (f=='')
                                {
                                  $("#nameError").html("Enter Name");
                                  return false;
                                }

                               else if (filter.test(f))
                                 {
                                    $("#nameError").html(" ");
                                    return true;
                                 }
                                else
                                 {
                                   $("#nameError").html("Enter Valid Name");
                                   return false;
                                 }
            }
       
       function validateEmail()
            {
              var e = email.val();
              var filter = /^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)*@[A-Za-z0-9]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,3})$/;
              if (e=='')
                {
                        $("#emailError").html("Enter Email");
                        return false;
                }

                else if (filter.test(e))
                {
                        $("#emailError").html(" ");
                        return true;
                }
                else
                {
               
                        $("#emailError").html("Enter Valid Email");
                        return false;
                }
            }

         function validateCity()
           {
                           var a = city.val();
                           if(a=='0')
                             {
                              $("#dError").html("please enter City");
                              return false;
                              }
                           else 
                            {
                            $("#dError").text(" ");
                            return true;
                            }
          }  
       
            $("#submit").click(function submitItem() {
                
            if (validateName()  & validateStatus() & Checkfiles())
            {
                return true;
            }
            else
            {
                return false;
            }

        });
           
        });
        