 
function addMoreViedo() {

	var ni = document.getElementById('addMoreVideo');
	var numi = document.getElementById('theValueVideo');
	var num = (document.getElementById('theValueVideo').value -1)+ 2;
	document.getElementById('theValueNosVideo').value += ","+num;	
	//document.getElementById('max').value += ","+num;	
	numi.value = num;
	
	var newdiv = document.createElement('fieldset');
	
	var divIdName = 'my'+num+'Div';
	
	newdiv.setAttribute('id',divIdName);
	
	
	
	var text = '<section><label>Title</label><div><input type="text" name="productVideoTitle'+num+'" id="productVideoTitle'+num+'"  /></div></section><section><label>Description</label><div><textarea  name="productVideoDescription'+num+'" id="productVideoDescription'+num+'" ></textarea></div></section><section><label>Video Image</label><div><input type="file" name="productVideoImage'+num+'" id="productVideoImage'+num+'"  /></div></section><section><label>Link</label><div><input type="text" name="productVideoLink'+num+'" id="productVideoLink'+num+'"  /></div></section><section><label>Embeded Code</label><div><textarea  name="productEmbedCode'+num+'" id="productEmbedCode'+num+'" ></textarea></div></section><section><label>Make Default</label><div><input type="radio" name="defaultVideo'+num+'" id="defaultVideo1'+num+'" value="1" />Yes<input type="radio" name="defaultVideo'+num+'" id="defaultVideo2'+num+'" value="0" checked="checked" />No</div></section> ';
	
	//alert(text3);
	newdiv.innerHTML = text+'<a href=\'javascript:void(0)\' class=\'i_trashcan video-trash\' onclick=\'removeVideo(\"'+divIdName+'\",\"'+num+'\")\'>removeVideo </a> </li>';
	ni.appendChild(newdiv);
}

function removeVideo(divNum,num) {


	var numi = document.getElementById('theValueVideo');
	var num2 = (document.getElementById('theValueVideo').value -1);
	numi.value = num2;
	
	var d = document.getElementById('addMoreVideo');
	var olddiv = document.getElementById(divNum);
	d.removeChild(olddiv);
}


////////////////   Add More for Product Image ///////////////////////

function addMoreImage() {

	var ni = document.getElementById('addMoreImage');
	var numi = document.getElementById('theValueImage');
	var num = (document.getElementById('theValueImage').value -1)+ 2;
	document.getElementById('theValueNosImage').value += ","+num;	
	//document.getElementById('max').value += ","+num;	
	numi.value = num;
	
	var newdiv = document.createElement('fieldset');
	
	var divIdName = 'my'+num+'Div';
	
	newdiv.setAttribute('id',divIdName);
	
	
	
	var text = '<section><label>Title</label><div><input type="text" name="productImageTitle'+num+'" id="productImageTitle'+num+'"  /></div></section><section><label>Description</label><div><textarea  name="productImageDescription'+num+'" id="productImageDescription'+num+'" ></textarea></div></section><section><label>Image</label><div><input type="file" name="productImage'+num+'" id="productImage'+num+'"  /></div></section><section><label>Make Default</label><div><input type="radio" name="defaultImage'+num+'" id="defaultImage1'+num+'" value="1" />Yes<input type="radio" name="defaultImage'+num+'" id="defaultImage2'+num+'" value="0" checked="checked" />No</div></section>';
	
	//alert(text3);
	newdiv.innerHTML = text+' <a href=\'javascript:void(0)\' class=\'i_trashcan video-trash\' onclick=\'removeImage(\"'+divIdName+'\",\"'+num+'\")\'><img src="images/drop.png" border="0"></a> </li>';
	ni.appendChild(newdiv);
}

function removeImage(divNum,num) {


	var numi = document.getElementById('theValueImage');
	var num2 = (document.getElementById('theValueImage').value -1);
	numi.value = num2;
	
	var d = document.getElementById('addMoreImage');
	var olddiv = document.getElementById(divNum);
	d.removeChild(olddiv);
}
 

