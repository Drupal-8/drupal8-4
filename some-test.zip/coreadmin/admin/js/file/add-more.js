 
function addMoreRecord() {

	var ni = document.getElementById('addmore');
	var numi = document.getElementById('theValue');
	var num = (document.getElementById('theValue').value -1)+ 2;
	document.getElementById('theValueNos').value += ","+num;	
	//document.getElementById('max').value += ","+num;	
	numi.value = num;
	
	var newdiv = document.createElement('div');
	
	var divIdName = 'my'+num+'Div';
	
	newdiv.setAttribute('id',divIdName);
	
	
	
	var text = '<li style="float:left; margin:0 0 0 50px ; padding:0; width:140px; "><input type="text" name="min'+num+'" id="min'+num+'"  /></li><li style="float:left; margin:0 0 0 15px ; padding:0; width:300px; " ><input type="text" name="sequence'+num+'"  id="sequence'+num+'"/>';
	
	//alert(text3);
	newdiv.innerHTML = text+'&nbsp;<a href=\'javascript:void(0)\' onclick=\'removeElement(\"'+divIdName+'\",\"'+num+'\")\'><img src="images/drop.png" border="0"></a> </li>';
	ni.appendChild(newdiv);
}

function removeElement(divNum,num) {


	var numi = document.getElementById('theValue');
	var num2 = (document.getElementById('theValue').value -1);
	numi.value = num2;
	
	var d = document.getElementById('addmore');
	var olddiv = document.getElementById(divNum);
	d.removeChild(olddiv);
}
 
 
function addMoreRecordOne() {

	var ni = document.getElementById('addmoreOne');
	var numi = document.getElementById('theValueOne');
	var num = (document.getElementById('theValueOne').value -1)+ 2;
	document.getElementById('theValueNosOne').value += ","+num;	
	//document.getElementById('max').value += ","+num;	
	numi.value = num;
	
	var newdivOne = document.createElement('ul');
	
	var divIdNameOne = 'my'+num+'Div';
	
	newdivOne.setAttribute('id',divIdNameOne);
	
	
	
	var text = '<li><input type="text" style="height:30px;" name="minOne'+num+'" id="minOne'+num+'"  /></li><li><input style="height:30px;" type="text" name="sequenceOne'+num+'"  id="sequenceOne'+num+'"/>';
	
	//alert(text3);
	newdivOne.innerHTML = text+'&nbsp;<a href=\'javascript:void(0)\' class="move i_trashcan edit" onclick=\'removeElementOne(\"'+divIdNameOne+'\",\"'+num+'\")\'> </a> </li>';
	ni.appendChild(newdivOne);
}

function removeElementOne(divNum,num) {


	var numi = document.getElementById('theValueOne');
	var num2 = (document.getElementById('theValueOne').value -1);
	numi.value = num2;
	
	var d = document.getElementById('addmoreOne');
	var olddiv = document.getElementById(divNum);
	d.removeChild(olddiv);
}


 
