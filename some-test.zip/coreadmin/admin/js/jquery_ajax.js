function viewAccessories(id)
{
	//alert("----"+id);
	var src = 'pass.php';	
	$.ajax({
		url: src,
		data: 'action=manageAccessories&type=view&id='+id,
		cache: false,  //don't let jquery prevent caching if cacheParam is being used dataType: 'json',
		type:'GET',
		success: function(data, textStatus, XMLHttpRequest){			
		//alert(data);			
			$("#showHeading").html("");
			$("#showHeading").css("display","block");
			$("#showHeading").append(data);
	/*		if(id != '') {
				$("#btnSubmit").css("display", "block");
			} else{
				$("#btnSubmit").css("display", "none");
			}		*/
		
		},// refresh the calendar    

		error:function(XMLHttpRequest, textStatus, errorThrown){alert(textStatus); alert(errorThrown);}
	});  
}