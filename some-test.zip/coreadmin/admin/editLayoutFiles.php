<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php'); 
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$menuObj = new Menu();
$menuObj->checkPermission("manageTemplates.php");
$fileObj = new EditFiles();
$id=base64_decode($_GET['id']);
?>
<?php echo headcontent()// DOCTYPE,ContentType,Title,style.css,jquery.min.js,jquery-ui.min.js,jquery_ajax.js,ajax.js, Top Pageoptions  ?>

<SCRIPT src="js/common.js" language="javascript" type="text/javascript"></SCRIPT>
<!--				Light Box Starts			-->
<link rel="stylesheet" type="text/css" href="lightbox/doc/css/style.css">
<script type="text/javascript" src="lightbox/src/adapter/shadowbox-base.js"></script>
<script type="text/javascript" src="lightbox/src/shadowbox.js"></script>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Manage Layout Files</h1>
        
                
                <table class="documentation">
                    <tr>
                    <thead>
                    <th>SL.No</th>
                    <th>File Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </thead>
                    </tr>	 
                    <?php echo $fileObj->allHtmlFilesInformation($id); ?>
                </table>
            </form>
        </fieldset>
    </section>
</body>
</html>