<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();

$tempObj = new Template();
$result = $tempObj->getAllAdmin();

if (isset($_POST['submit'])) {  //print_r($_POST);die;
    $arr_error = $tempObj->validationAddTemp($_POST);
    //print_r($arr_error);die;
    if ($arr_error['ERROR']) {
        $tempObj->addTemplet($_POST); 
    }
    
}
echo headcontent();
?>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Add Template</h1>
        <fieldset>

            <form name="frmUser" id="frmUser" method="post">
               
                    <fieldset>
                        <label>Template Detail</label>
                        <div id="div_duplicateUser"></div>
                        <div id="div_duplicateEmail"></div>
                        <div id="divMessage"></div>
                        <?php echo $_SESSION['SESS_MSG'] ?>
                        <?php unset($_SESSION['SESS_MSG']) ?>

                        <section> <label for="templateName">Template Name</label>
                            <div>
                                <input type="text" name="templateName" id="templateName" class="wel"
                                       value="<?php echo $_POST['templateName']; ?>" />
                                <div id="chk_templateName"><?php echo $arr_error['templateName']; ?></div>
                            </div>
                        </section>

                        <section> <label for="offlineCode">Purchase Offline code</label>
                            <div>
                                <input type="text" name="offlineCode" id="offlineCode"
                                       value="<?php echo $_POST['offlineCode']; ?>" />
                                <div id="chk_offlineCode"><?php echo $arr_error['offlineCode']; ?></div>
                            </div>
                        </section>
                        <section> <label for="onlineCode">Purchase Online code</label>
                            <div>
                                <input type="text" name="onlineCode" id="onlineCode"
                                       value="<?php echo $_POST['onlineCode']; ?>" />
                                <div id="chk_onlineCode"><?php echo $arr_error['onlineCode']; ?></div>
                            </div>
                        </section>
                        <section> <label for="offlineCode">select  Users</label>
                            <div>
                                <?php echo $result; ?>
                            </div>
                        </section>
                       
                        <section id="layouts"> <label for="layout" id="layout_1">Layout1</label>
                            <div id="layout_1" ><input type="text" name="layout[]"  value="<?= $_POST['layout'][0] ?>" />
                            </div>
                            <div id="chk_onlineCode"><?php echo $arr_error['layout']; ?></div>
                        </section>
                       
                        <section> 
                            <div>
                                <button type="button" name="addlayout" id="addlayout">Add More Layout</button>
                                <div id="chk_layout"></div>
                            </div>
                        </section>

                    </fieldset>
                    <section>
                        <div style="width: 100%;text-align: center;">
                            <button type="submit" name="submit">Submit</button>
                            <!--<button type="button" name="back" onClick="hrefBack()" id="back">Back</button>-->
                        </div>
                    </section>

            </form>
        </fieldset>

        <div id="divTemp" style="display: none;"></div>
    </section>


    <script>
        var i = 2;
        $("#addlayout").click(function () {
            $("#layouts").append('<label for="layout" id="lbl_'+i+'">Layout' + i + '</label><div id="layout_'+i+'"><input type="text" name="layout[]"  /><img src="cross.jpeg" height=15 width=15 id="cross_' + i + '" onclick="deleteLayout('+i+')" ></div>');

            i++;
        });
        
        $("#templateName").bind('blur change', function() {
            
            var v = $(this).val();
            $.ajax({
                url: 'getTemplate.php',
                type: 'GET',
                data: {
                    name: v},
                success: function (x) {
                    $("#chk_templateName").html(x);
                    return false;
                }
            });
        });               
        
        
        function deleteLayout(n){
            $('#layout_'+n).remove();
            
            $('#lbl_'+n).remove();
            i--;
        }

    </script>



