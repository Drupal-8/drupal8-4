<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
require_once('validation_class.php');

$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$tempObj = new Template();
$layObj = new Layout();
$id=base64_decode($_GET['id']);
$EditResult=$tempObj->getResultLayout($id);
$allHeader=$tempObj->getResultLayoutHeaders($id);
if (isset($_POST['submit'])) {  //print_r($_POST);print_r($_FILES);die;
    $arr_error = $layObj->validationforUploadLayout($_POST, $_FILES,1);
//    echo "<pre>";
//    print_r($_FILES);die;
    if ($arr_error['ERROR']) {
        
        $layObj->editUploadLayoutFile($_POST, $_FILES);
    }
}
echo headcontent();
?>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Edit Layout</h1>
        <fieldset>

            <form name="frmUser" id="frmUser" method="post" enctype="multipart/form-data">

                <fieldset>
                    <label>Upload Layout</label>

                    <?php echo $_SESSION['SESS_MSG'] ?>
                    <?php unset($_SESSION['SESS_MSG']) ?>

                    <section> <label for="templateName">Template Name</label>
                            <div>
                                <input type="text" name="temp" id="temp" disabled value="<?php echo $EditResult->t_name?>" />
                                <input type="hidden" name="template" id="template" value="<?php echo $EditResult->id?>" />
                            </div>
                        </section>
                    <section> <label for="lay">Layout Name</label>
                            <div>
                                <input type="text" name="lay" id="temp" disabled value="<?php echo $EditResult->layout_name?>" />
                                <input type="hidden" name="layouts" id="layouts" value="<?php echo $id?>" />
                            </div>
                        </section>
                </fieldset>
                <fieldset>
                    <label>Upload template Images</label>
                    <section> <label for="file">Template Images</label>
                        <div>
                            <input type="file" name="image[]" id="image" multiple />
                            <div id="chk_file"><?php echo $arr_error['image']; ?></div>
                        </div>
                    </section>
                </fieldset>
                <fieldset id='appaend'>
                    <label>Upload HTML Section</label>
                    <label>Upload header</label>
                    <section> <label for="file">Header Section</label>
                        <div>
                            <input type="file" name="headerFile" id="image"  />
                            <div id="chk_file"><?php echo $arr_error['headerFile']; ?></div>
                        </div>
                    </section>
                    <section> <label for="file">Header Image</label>
                        <div>
                            <input type="file" name="headerImage" id="image"  />
                            <div id="chk_file"><?php echo $arr_error['headerImage']; ?></div>
                        </div>
                    </section>
                    <section> <label for="file">Header Height</label>
                        <div>
                            <input type="text" name="headerHeight" id="heigh" value="<?php echo $EditResult->height; ?>" />
                            <div id="chk_file"><?php echo $arr_error['headerHeight']; ?></div>
                        </div>
                    </section>
                    <!--///////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->
                    <fieldset id='appaend-html'>
                        <?php 
                                        if(count($allHeader)){$i=1;
                                        foreach($allHeader as $header){
                                    ?>
                        <label>Upload html Section(<?php echo $i;?>)</label>

                        <section> <label for="file">Html Section </label>
                            <div>
                                <input type="file" name="htmlSecFile[<?php echo $header['id'];?>]" id="htmlSec_<?php echo $i;?>"  />
                                <div id="chk_file"></div>
                            </div>
                        </section>
                        <section> <label for="file">Html Thumb Image</label>
                            <div>
                                <input type="file" name="htmlSecThumb[<?php echo $header['id'];?>]" id="htmlThumb_<?php echo $i;?>"/>
                                <div id="chk_file"></div>
                            </div>
                        </section>
                        <section> <label for="file">Header Height</label>
                            <div>
                                <input type="text" name="htmlSecHeight[]" id="heigh_<?php echo $i;?>" value="<?php echo $header['height'];?>"/>
                                <div id="chk_file"></div>
                            </div>
                            
                        </section>
                        <?php $i++;}}?>
                    </fieldset>
                    <!--     ///////////////////////////////////////////////////////////////////////////////////////////////               -->
                </fieldset>
<!--                <section> 
                    <div>
                        <button type="button" name="addlayout" id="addlayout">Add More Layout</button>
                        <div id="chk_layout"></div>
                    </div>
                </section>-->
                <section>
                    <div style="width: 100%;text-align: center;">
                        <button type="submit" name="submit">Submit</button>
                        <!--<button type="button" name="back" onClick="hrefBack()" id="back">Back</button>-->
                    </div>
                </section>
            </form>
        </fieldset>
    </section>

    




