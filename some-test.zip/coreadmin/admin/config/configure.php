<?php
$docRoot = $_SERVER['DOCUMENT_ROOT'];
$docRoot .= "/CSS2265/";
$sitepath = "http://norefresh.thesparxitsolutions.com/raushan/coreadmin/";
$imageMagickPath  = "/usr/bin/convert";
$sitename = "TEMPLATE ADMIN";

define('__SITENAME__', $sitename);


// Local Database Settings
$config['server'] = 'localhost';
$config['database'] = 'A_EMAIL';
$config['user'] ='norefresh';
$config['pass'] ='norefresh@123';
//=================================================================

date_default_timezone_set('Asia/Calcutta');

define('CONFIGSERVER', $config['server']);
define('CONFIGDATABASE', $config['database']);
define('CONFIGUSER', $config['user']);
define('CONFIGPASS', $config['pass']);
define('CONFIGIMAGEMAGICPATH', $imageMagickPath);
define("ABSOLUTEPATH" , $docRoot);
define("SITEPATH" , $sitepath);


//RAJEEV
define('SEARCHTEXT', "Search");
define('DEFAULTDATEFORMAT', "d-m-Y");
define('BASEUPLOADFILE',$docRoot."files/");
define('BASEUPLOADFILEPATH',"../files/");
define('FLAGORIGINAL',BASEUPLOADFILE."flag/flagoriginal/");
define('FLAGTHUMB',BASEUPLOADFILE."flag/flagthumb/");
define('FLAGTHUMB_URL',SITE_URL."files/flag/flagthumb/");
define('FLAGPATH',BASEUPLOADFILEPATH."flag/flagthumb/");
define('IMAGEMAGICPATH', $imageMagickPath);

?>
