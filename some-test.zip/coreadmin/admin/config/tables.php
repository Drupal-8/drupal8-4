<?php
define('PREFIX', 'cal_');

define('TBL_ADMINLOGIN', PREFIX.'adminlogin');
define('TBL_MENU', PREFIX.'adminmenu');
define('TBL_ADMINPERMISSION', PREFIX.'adminpermission');
define('TBL_ADMINLEVEL', PREFIX.'adminlevel');
define('TBL_SYSTEMCONFIG', PREFIX.'admin_system_config');

define('TBL_LOGDETAIL', PREFIX.'logdetail');
define('TBL_SESSIONDETAIL', PREFIX.'admin_sessiondetail');

define('TBL_TEMPLATES', PREFIX.'templates');

define('TBL_LAYOUTS', PREFIX.'layouts');
define('TBL_LAYOUTS_MANAGE', PREFIX.'layouts_manage');

define('TBL_SECTION_MANAGE', PREFIX.'section_manage');
define('TBL_IMAGES', PREFIX.'images');

?>
