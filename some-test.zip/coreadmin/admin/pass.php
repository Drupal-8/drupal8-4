<?php

ob_start();
session_start();

$action = $_GET['action'];
$mode = $_GET['mode'];
$type = $_GET['type'];
$user = $_GET['user'];
//echo "<pre>";
//print_r($_POST);
//echo "<br />";
//print_r($_REQUEST);

/* * ************************** autoload the classes *************** */

require_once('includes/function/autoload.php');

//Manage Admin
if ($action == 'admin') {
	$admObj = new AdminDetail;
	if ($type == 'changestatus') {
		$admObj->changStatus($_GET);
	}
	if ($type == 'delete') {
		if ($user == 'admin') {
			$admObj->deleteRecord($_GET);
		} else {
			header("Location:manageProduct.php?searchtxt=" . $_POST['searchtext']);
			die;
		}
	}
}

//Manage Category
if ($action == 'category') {
	$catObj = new Category();
	if ($type == 'changestatus') {
		$catObj->changeStatus($_GET);
	}
	if ($type == 'delete') {
		$catObj->deleteRecord($_GET);
	}
	if ($type = 'deleteall') {
		if ($_POST['Input']) {
			$catObj->deleteAllValues($_POST);
		} else {
			header("Location:manageCategory.php?searchtxt=" . $_POST['searchtext']);
			exit;
		}
	}
}

//Manage Product
if ($action == 'manageproduct') {
	$prodObj = new Product();

	if ($type == 'brand') {
		$prodObj->getBrand($_GET['pId'], $_GET['id'], $_GET['error']);
	}
	if ($type == 'subcategory') {
		$prodObj->getSubCategory($_GET['id'], $_GET['sId']);
	}
	if ($type == 'delete') {
		$prodObj->deleteRecord($_GET);
	}
	if ($type == 'changestatus') {
		$prodObj->changeStatus($_GET);
	}
	if ($type = 'deleteall') {
		if ($_POST['Input']) {
			$prodObj->deleteAllValues($_POST);
		} else {
			header("Location:manageProduct.php?searchtxt=" . $_POST['searchtext']);
			exit;
		}
	}
}

//Manage User
if ($action == 'manageuser') {
	$userObj = new User();
	if ($type == 'changestatus') {
		$userObj->changeValueStatus($_GET);
	}
	if ($type == 'delete') {
		$userObj->deleteValue($_GET);
	}
	if ($type == 'deleteall') {
		if ($_POST['Input']) {
			$userObj->deleteAllValues($_POST);
		} else {
			header("Location:manageUser.php?searchtxt=" . $_POST['searchtext']);
			exit;
		}
	}
}

//manage Country
if ($action == 'template') {
	$tempObj = new Template;
	
	if ($type == 'delete') {
		$tempObj->deleteRecord($_GET);
	}
	
}
if ($action == 'layout') {
	$tempObj = new Template;
	
	if ($type == 'delete') {
		$tempObj->deleteRecordLayout($_GET);
	}
	
}

// Manage State
if ($action == 'state') {
	$stateObj = new State();
	if ($type == 'changestatus') {
		$stateObj->changeValueStatus($_GET);
	}
	if ($type == 'delete') {
		$stateObj->deleteValue($_GET);
	}
	if ($type == 'deleteall') {
		if (!$_POST['Input']) {
			header("Location:manageState.php?searchtxt=" . $_POST['searchtext']);
			exit;
		} else {
			$stateObj->deleteAllValues($_POST);
		}
	}
	if ($type == 'getCountryList') {
		$genObj = new GeneralFunctions();
		$genObj->getCountryList($_GET['zoneid'], "", $_GET['mode']);
	}
	if ($type == 'getStateList') {
		$genObj = new GeneralFunctions();
		$genObj->getStateInDropdown12($_GET['countryID']);
	}
}

//Manage Provider
if ($action == 'manageprovider') {
	$provObj = new Provider();
	if ($type == 'changestatus') {
		$provObj->changeStatus($_GET);
	}
	if ($type == 'delete') {
		$provObj->deleteRecord($_GET);
	}
	if ($type == 'deleteall') {
		if ($_POST['Input']) {
			$provObj->deleteAllValues($_POST);
		} else {
			header("Location:manageProvider.php?searchtxt=" . $_POST['searchtext']);
			exit;
		}
	}
}




if ($action == 'mailtype') {

	$tempObj = new Template();

	if($type == 'deleteall'){

		header("Location:manageMailType.php?searchtxt=".$_POST['searchtext']);

	}

}

?>
