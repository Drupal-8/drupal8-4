<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$name=$_GET['name'];
$tempObj = new Template();
$result = $tempObj->getTempName($name);
echo $result;

?>

