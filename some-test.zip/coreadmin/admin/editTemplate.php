<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();

$tempObj = new Template();
$id=base64_decode($_GET['id']);
$EditResult=$tempObj->getResult($id); 
$result = $tempObj->getAllAdmin($EditResult->users);

$templateName=$_POST['templateName']?$_POST['templateName']:$EditResult->t_name;
$offlineCode=$_POST['offlineCode']?$_POST['offlineCode']:$EditResult->offline_pcode;
$onlineCode=$_POST['onlineCode']?$_POST['onlineCode']:$EditResult->online_pcode;


if (isset($_POST['submit'])) {  //print_r($_POST);die;
    $arr_error = $tempObj->validationAddTemp($_POST,1);
    //print_r($arr_error);die;
    if ($arr_error['ERROR']) {
        $tempObj->editTemplet($_POST); 
    }
    
}
echo headcontent();
?>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Edit Template</h1>
        <fieldset>

            <form name="frmUser" id="frmUser" method="post">
               
                    <fieldset>
                        <label>Template Detail</label>
                        <?php echo $_SESSION['SESS_MSG'] ?>
                        <?php unset($_SESSION['SESS_MSG']) ?>

                        <section> <label for="templateName">Template Name</label>
                            <div>
                                <input type="text" name="templateName" id="templateName" class="wel"
                                       value="<?php echo $templateName; ?>" disabled />
                                <div id="chk_templateName"><?php echo $arr_error['templateName']; ?></div>
                            </div>
                        </section>

                        <section> <label for="offlineCode">Purchase Offline code</label>
                            <div>
                                <input type="text" name="offlineCode" id="offlineCode"
                                       value="<?php echo $offlineCode; ?>" />
                                <div id="chk_offlineCode"><?php echo $arr_error['offlineCode']; ?></div>
                            </div>
                        </section>
                        <section> <label for="onlineCode">Purchase Online code</label>
                            <div>
                                <input type="text" name="onlineCode" id="onlineCode"
                                       value="<?php echo $onlineCode; ?>" />
                                <div id="chk_onlineCode"><?php echo $arr_error['onlineCode']; ?></div>
                            </div>
                        </section>
                        <section> <label for="offlineCode">select  Users</label>
                            <div>
                                <?php echo $result; ?>
                            </div>
                        </section>
                       
                        <section id="layouts"> 
                            <?php echo $tempObj->getLayOuts($id); ?>
                        </section>
                       
<!--                        <section> 
                            <div>
                                <button type="button" name="addlayout" id="addlayout">Add More Layout</button>
                                <div id="chk_layout"></div>
                            </div>
                        </section>-->
<input type="hidden" name="id" value="<?php echo $id; ?>" />
                    </fieldset>
                    <section>
                        <div style="width: 100%;text-align: center;">
                            <button type="submit" name="submit">Submit</button>
                            <button type="button" name="back" onClick="hrefBack()" id="back">Back</button>
                        </div>
                    </section>

            </form>
        </fieldset>

        <div id="divTemp" style="display: none;"></div>
    </section>


    <script>
        var i = 2;
        $("#addlayout").click(function () {
            $("#layouts").append('<label for="layout" id="lbl_'+i+'">Layout' + i + '</label><div id="layout_'+i+'"><input type="text" name="layout[]"  /><img src="cross.jpeg" height=15 width=15 id="cross_' + i + '" onclick="deleteLayout('+i+')" ></div>');

            i++;
        });
        
        $("#templateName").bind('blur change', function() {
            
            var v = $(this).val();
            $.ajax({
                url: 'getTemplate.php',
                type: 'GET',
                data: {
                    name: v},
                success: function (x) {
                    $("#chk_templateName").html(x);
                    return false;
                }
            });
        });               
        
        
        function deleteLayout(n){
            $('#layout_'+n).remove();
            
            $('#lbl_'+n).remove();
            i--;
        }
        function hrefBack() {
	history.go(-1);	
}

    </script>



