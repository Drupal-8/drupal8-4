<?php
session_start();
error_reporting(0);
class GeneralFunctions extends MySqlDriver {

	function __construct()
	{
		$obj = new MySqlDriver;
	}

        /*  return system configuration name    */
	function getSystemConfigValue($systemName){
		return $this->fetchValue(TBL_SYSTEMCONFIG,"systemVal","systemName='$systemName'");
	}
        /*  return system configuration Currency Symbol   */
	function getDefaultCurrencySymbol() {
		$sql = "SELECT TB2.sign FROM ".TBL_CURRENCY." AS TB1 INNER JOIN ".TBL_CURRENCY_DETAIL." AS TB2 ON (TB1.id=TB2.id) WHERE TB1.isDefault='1' AND TB1.status='1'";
		$rst = $this->executeQry($sql);
		$line = $this->getResultObject($rst);
		return $line->sign;
	}


        /*  Get Country DropDown list    */
	function getSetCountryInDropdown($countryId)
	{
		$sql = "SELECT tbl1.countryId, tbl2.countryName FROM ".TBL_COUNRTYSETTING." AS tbl1 INNER JOIN ".TBL_COUNTRY_DESCRIPTION." AS tbl2 ON (tbl1.countryId = tbl2.countryId) WHERE tbl2.langId='".$_SESSION['DEFAULTLANGUAGE']."' AND tbl1.isDeleted='0'";

		$rst = $this->executeQry($sql);
		$preTable = " ";
		while($row = $this->getResultObject($rst)){
			if($countryId == $row->countryId){
				$selected = 'selected="selected"';
			}else{
				$selected = '';
			}
			$preTable .= "<option value='$row->countryId' $selected >".ucwords($row->countryName)."</option>";
		}
		return $preTable;
	}
      /*  Get Country DropDown list    */
	function getCountryInDropdown($countryId)
	{
		$sql = "SELECT id,countryName FROM ".TBL_COUNTRY." AS tbl1 INNER JOIN ".TBL_COUNTRY_DESCRIPTION." AS tbl2 ON (tbl1.id = tbl2.countryId) WHERE tbl2.langId='".$_SESSION['DEFAULTLANGUAGE']."' AND tbl1.isDeleted='0'";

		$rst = $this->executeQry($sql);
		$preTable = " ";
		while($row = $this->getResultObject($rst)){
			if($countryId == $row->id){ $selected = 'selected="selected"';}else{  $selected = '';}
			$preTable .= "<option value='$row->id' $selected >".ucwords($row->countryName)."</option>";
		}
		return $preTable;
	}
      /*  Get language flag    */
	function getLanguageViewTextBox($name,$tablename,$tableid,$tableIdName){

		$rst = $this->selectQry(TBL_LANGUAGE,"status='1'   AND isDeleted='0' order by languageName asc","","");
		$num = $this->getTotalRow($rst);
		if($num){
			$genTable = ""; $i = 0;
			while($line = $this->getResultObject($rst)) {
				$value = $this->fetchValue($tablename,$name,"$tableIdName=$tableid and langId = '".$line->id."'");
				if($i == 0) {
					$genTable .= '<span><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  '.stripslashes($value).'<br /></span>';
				} else {
					$genTable .= '<span><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  '.stripslashes($value).' <br /></span> ';
				}
				$i++;
			}
		}
		return $genTable;
	}
 /*  Get State DropDown list for a country   */
	function getStateInDropdown($countryId,$stateId){
		$sql = "SELECT tbl1.id,tbl2.stateName FROM ".TBL_STATE." AS tbl1 INNER JOIN ".TBL_STATE_DESCRIPTION." AS tbl2 ON (tbl1.id = tbl2.stateId) WHERE tbl2.langId='$_SESSION[DEFAULTLANGUAGE]'  AND tbl1.isDeleted='0' AND tbl1.countryId='$countryId'";
		$rst = $this->executeQry($sql);
		$preTable = "";
		$preTable .= '<select name="stateId" id="m__State" class="wel" >';
		$preTable .='<option value="">Select State</option>';
		while($row = $this->getResultObject($rst)){
			if($stateId == $row->id){ $selected = 'selected="selected"';}else{  $selected = '';}
			$preTable .= "<option value='$row->id' $selected >".ucwords($row->stateName)."</option>";
		}
		$preTable .= '</select>';
		echo $preTable;
	}
 /*  Get State DropDown list for a country   */
	function getStateInDropdown12($countryId){
	 $sql = "SELECT tbl1.id,tbl2.stateName FROM ".TBL_STATE." AS tbl1 INNER JOIN ".TBL_STATE_DESCRIPTION." AS tbl2 ON (tbl1.id = tbl2.stateId) WHERE tbl2.langId='$_SESSION[DEFAULTLANGUAGE]' AND tbl1.isDeleted='0' AND tbl1.countryId='$countryId'";
		$rst = $this->executeQry($sql);
		$preTable = "";
		$preTable .= '<select name="stateId" id="m__State" class="wel" >';
		$preTable .='<option value="">Select State</option>';
		while($row = $this->getResultObject($rst)){
			if($countryId == $row->id){ $selected = 'selected="selected"';}else{  $selected = '';}
			$preTable .= "<option value='$row->id' $selected >".ucwords($row->stateName)."</option>";
		}
		$preTable .= '</select>';
		echo $preTable;
	}
 /*  Get language Name DropDown list for a country   */
	function getLanguageInDropDown($langId=''){
		$preTable = "<option value=''>Please Select Language</option>";
		$rst = $this->selectQry(TBL_LANGUAGE,"status='1' AND isDeleted='0' order by languageName asc","","");
		$num = $this->getTotalRow($rst);
		if($num){
			while($row = $this->getResultObject($rst)){
				if($langId == $row->id){ $sel = "selected='selected'";}else{$sel = "";}
				$preTable.= "<option value='$row->id' $sel>".ucwords(utf8_encode($row->languageName))."</option>";
			}
		}
		return $preTable;
	}
 /*  return all language as array   */
	function getAllLanguage()
	{
		$sqlLang = $this->executeQry("SELECT L.* FROM ".TBL_LANGUAGE." AS L Left Join ".TBL_LANGUAGEATTRIBUTE." AS LA on L.id=LA.langId WHERE L.status='1' AND LA.langId>0");

		$langArr = array();
			
		while ($rowLanguage = $this->getResultObject($sqlLang))
		{
			$sqlCurrency = $this->executeQry("SELECT * FROM ".TBL_CURRENCY." WHERE id=".$rowLanguage->curId."");
			$rowCurrency = $this->getResultObject($sqlCurrency);
			$objLang = (object) $objLang;
			$objLang->id = $rowCurrency->id;
			$objLang->currencyCodeT = $rowCurrency->currencyCodeT;
			$objLang->currencyValue = $rowCurrency->currencyValue;
			$objLang->decimalPlace = $rowCurrency->decimalPlace;
			$objLang->SeparatorFrom = $rowCurrency->SeparatorFrom;
			$objLang->showIn = $rowCurrency->showIn;
			$langArr[] = $objLang;
			unset($objLang);
		}
		return $langArr;
	}

 /*  Get language type input box with respective language flag   */
	function getLanguageTextBox($name,$id,$arr_error){
		$rst = $this->selectQry(TBL_LANGUAGE,"status='1'  AND isDeleted='0' order by languageName asc","","");
		$num = $this->getTotalRow($rst);
		if($num){
			$genTable = "";
			$i = 0;
			while($line = $this->getResultObject($rst)) {
				if($i == 0) {
					$genTable .= '<li><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  <input type="'.$type.'" name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" class="wel" value="" /><p style="padding-left:150px;">'.$arr_error[$name."_".$line->id].'</p> </li> ';
						
				} else {
					$genTable .= '<li class="lable"></li><li><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  <input type="'.$type.'" name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" class="wel" value="" /><p style="padding-left:150px;">'.$arr_error[$name."_".$line->id].'</p> </li> ';

				}

				$i++;
			}
		}
		return $genTable;
	}

 /*  Get language type input box with respective language flag   */	

	function getLanguageEditTextBox($name,$id,$tablename,$tableid,$tableIdName,$arr_error){
		$rst = $this->selectQry(TBL_LANGUAGE,"status='1'   AND isDeleted='0'
order by languageName asc","","");		
		$num = $this->getTotalRow($rst);
		if($num){
			$genTable = "";
			while($line = $this->getResultObject($rst)) {
				$value =
				$this->fetchValue($tablename,$name,"$tableIdName=$tableid and langId =
'".$line->id."'");		
				$genTable .= '<span><img
src="../files/flag/flagthumb/'.$line->languageFlag.'"
title="'.$line->languageName.'"></span><input type="'.$type.'"
name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" 
value="'.stripslashes($value).'" /><p>'.$arr_error[$name."_".$line->id].'</p>'; 
			}
		}
		return $genTable;
	}
 /*  Get language type input box with respective language flag   */
	function getLanguageEditTextBoxAttribute($name,$id,$tablename,$tableid,$tableIdName,$arr_error){
		$rst = $this->selectQry(TBL_LANGUAGE,"status='1'   AND isDeleted='0' order by languageName asc","","");
		$num = $this->getTotalRow($rst);
		if($num){
			$genTable = ""; $i = 0;
			while($line = $this->getResultObject($rst)) {
				$value = $this->fetchValue($tablename,$name,"$tableIdName=$tableid and langId = '".$line->id."'");
				if($i == 0) {
					$genTable .= '<li ><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  <input type="'.$type.'" name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" class="wel" value="'.stripslashes($value).'" /><input type="hidden" name="prev_'.$name.'_'.$line->id.'" class="wel" value="'.stripslashes($value).'" /><p style="padding-left:150px;">'.$arr_error[$name."_".$line->id].'</p> </li> ';
				} else {
					$genTable .= '<li class="lable"></li><li ><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  <input type="'.$type.'" name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" class="wel" value="'.stripslashes($value).'" /><input type="hidden" name="prev_'.$name.'_'.$line->id.'" class="wel" value="'.stripslashes($value).'" /><p style="padding-left:150px;">'.$arr_error[$name."_".$line->id].'</p> </li> ';
				}
				$i++;
			}
		}
		return $genTable;
	}

	 /*  Get language type input textarea with respective language flag   */
	function getLanguageTextarea($name,$id,$arr_error){
		$rst = $this->selectQry(TBL_LANGUAGE,"status='1'  AND isDeleted='0' order by languageName asc","","");
		$num = $this->getTotalRow($rst);
		if($num){
			$genTable = "";
			$i = 0;
			while($line = $this->getResultObject($rst)) {
				if($i == 0) {
					$genTable .= '<li><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'"> <textarea name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" class="wel-textarea" rows="5" cols="40" >'.$_REQUEST[$name.'_'.$line->id].'</textarea><p style="padding-left:150px;">'.$arr_error[$name."_".$line->id].'</p> </li> ';
				} else {
					$genTable .= '<li class="lable"></li><li><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'"> <textarea name="'.$name.'_'.$line->id.'" id="'.$id.'_'.$line->languageCode.'" class="wel-textarea" rows="5" cols="40" >'.$_REQUEST[$name.'_'.$line->id].'</textarea><p style="padding-left:150px;">'.$arr_error[$name."_".$line->id].'</p> </li> ';
				}
				$i++;
			}
		}
		return $genTable;
	}

 /*  Get language type text output with respective language flag   */
	function getLanguageViewTextarea($name,$tablename,$tableid,$tableIdName){
		$rst = $this->selectQry(TBL_LANGUAGE,"status='1'   AND isDeleted='0' order by languageName asc","","");
		$num = $this->getTotalRow($rst);
		if($num){
			$genTable = ""; $i = 0;
			while($line = $this->getResultObject($rst)) {
				$value = $this->fetchValue($tablename,$name,"$tableIdName=$tableid and langId = '".$line->id."'");
				if($i == 0) {
					$genTable .= '<li ><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'">  '.stripslashes($value).' </li> ';
				} else {
					$genTable .= '<li class="lable"></li><li ><img src="../files/flag/flagthumb/'.$line->languageFlag.'" title="'.$line->languageName.'"> '.stripslashes($value).' </li> ';
				}
				$i++;
			}
		}
		return $genTable;
	}
 /*  Get Attribute list in drop down   */
	function getAttributeList($id) {
		$genTable = "";
		$sql = $this->executeQry("select a.id,ad.attributeName from ".TBL_ATTRIBUTE." as a, ".TBL_ATTRIBUTE_DESCRIPTION." as ad where 1 and a.status = '1' and a.isDeleted = '0' and a.id = ad.attributeId and ad.langId = '".$_SESSION['DEFAULTLANGUAGE']."' order by ad.attributeName");
		$num = $this->getTotalRow($sql);
		if($num > 0) {
			while($line = $this->getResultObject($sql)) {
				$sel = ($id == $line->id)?'selected="selected"':'';
				$genTable .= '<option value="'.$line->id.'" '.$sel.'>'.$line->attributeName.'</option>';
			}
		}
		return $genTable;
	}

 /*  Get category list in drop down   */
	function getCategoryList($id)
	{
		$genTable = "";
		$aaaa = "select a.id,ad.categoryName from ".TBL_CATEGORY." as a, ".TBL_CATEGORY_DESCRIPTION." as ad where 1 and a.parent_id = 0 and a.status = '1' and a.isDeleted = '0' and a.id = ad.catId and ad.langId = '".$_SESSION['DEFAULTLANGUAGE']."' order by a.id";
		//echo count($id);
		$id1 = substr($id,1);
		$id2 = substr($id1,0,-1);
		if($id2){
			$id21 = explode("-", $id2);
		}
		//print_r($id21);
		$sql = $this->executeQry($aaaa);
		$num = $this->getTotalRow($sql);
		if($num > 0) {
			while($line = $this->getResultObject($sql)) {
				 
				$sel = '';
				$flag = 0;
				foreach($id21 as $catid){

					if($catid == $line->id){
						$sel = 'selected="selected"';
						break;
					}
				}
				//echo $sel;
				//exit;

				$genTable .= '<option value="'.$line->id.'" "'.$sel.'" >'.stripslashes(stripslashes($line->categoryName)).'</option>';

				$genTable .= $this->subCategory($line->id,1,$id);
			}
		}
		return $genTable;
	}
         /*  Get category list in drop down   */
	function getCategoryListSingle($id) {
	  
		$genTable = "";
		$aaaa = "select a.id,ad.categoryName from ".TBL_CATEGORY." as a, ".TBL_CATEGORY_DESCRIPTION." as ad where 1 and a.parent_id = 0 and a.status = '1' and a.isDeleted = '0' and a.id = ad.catId and ad.langId = '".$_SESSION['DEFAULTLANGUAGE']."' order by a.id";
		//echo $aaaa;
		//echo $id;
		//exit;
		$sql = $this->executeQry($aaaa);
		$num = $this->getTotalRow($sql);
		if($num > 0) {
			while($line = $this->getResultObject($sql)) {
				$sel = ($id == $line->id)?'selected="selected"':'';
				$genTable .= '<option value="'.$line->id.'" '.$sel.'>'.stripslashes(stripslashes($line->categoryName)).'</option>';
				$genTable .= $this->subCategorySingle($line->id,1,$id);
			}
			//$genTable .= '<option value="'.$line->id.'" '.$sel.'>'.$id.'</option>';
		}
		return $genTable;
	}


	function subCategorySingle($pid,$dashes,$id) {
		$dash = str_repeat('&nbsp;',$dashes);
		$bbb = "select a.id,ad.categoryName from ".TBL_CATEGORY." as a, ".TBL_CATEGORY_DESCRIPTION." as ad where 1 and a.parent_id = '".$pid."' and a.status = '1' and a.isDeleted = '0' and a.id = ad.catId and ad.langId = '".$_SESSION['DEFAULTLANGUAGE']."' order by a.id";
		$sql = $this->executeQry($bbb);
		$num = $this->getTotalRow($sql);
		if($num > 0) {
			while($line = $this->getResultObject($sql)) {
				$sel = ($id == $line->id)?'selected="selected"':'';
				$genTable .= '<option value="'.$line->id.'" '.$sel.'>'.$dash.$line->categoryName.'</option>';
				$genTable .= $this->subCategorySingle($line->id,($dashes + 1),$id);
			}
			//$genTable .= '<option value="'.$line->id.'" '.$sel.'>'.$dash.$line->categoryName.'</option>';
			return $genTable;
		} else {
			return false;
		}
	}



	function subCategory($pid,$dashes,$id) {
		$id1 = substr($id,1);
		$id2 = substr($id1,0,-1);
		if($id2){
			$id21 = explode("-", $id2);
		}
		$dash = str_repeat('&nbsp;',$dashes);
		$bbb = "select a.id,ad.categoryName from ".TBL_CATEGORY." as a, ".TBL_CATEGORY_DESCRIPTION." as ad where 1 and a.parent_id = '".$pid."' and a.status = '1' and a.isDeleted = '0' and a.id = ad.catId and ad.langId = '".$_SESSION['DEFAULTLANGUAGE']."' order by a.id";
		$sql = $this->executeQry($bbb);
		$num = $this->getTotalRow($sql);
		if($num > 0) {
			while($line = $this->getResultObject($sql)) {
				//print_r($id21);
				foreach($id21 as $catid){
					if($catid == $line->id){
						$sel = 'selected="selected"';
						break;
					}
				}

				//$sel = ($id == $line->id)?'selected="selected"':'';
				$genTable .= '<option value="'.$line->id.'" "'.$sel.'" >'.$dash.stripslashes($line->categoryName).'</option>';
				$sel = '';
				$genTable .= $this->subCategory($line->id,($dashes + 1),$id);
			}
			return $genTable;
		} else {
			return false;
		}
	}



}// End Class


?>
