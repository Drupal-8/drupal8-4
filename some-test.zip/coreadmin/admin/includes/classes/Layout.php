<?php

session_start();

class Layout extends MySqlDriver {

    function __construct() {
        $this->obj = new MySqlDriver;
    }

    function uploadLayoutFile($post, $files) {
        $this->writeJason($post, $files);
        $all = array($post['htmlSecHeight'], $files['htmlSecFile'], $files['htmlSecThumb']);
        //Uploading template images to the images folder
//        echo'<pre>';
//        print_r($all);die;

        $sql = "select a.*,b.* from " . TBL_TEMPLATES . " as a  join " . TBL_LAYOUTS . " as b on a.id=b.tem_id and b.id='" . $post['layouts'] . "'";
        $rst = $this->executeQry($sql);
        $line = $this->getResultObject($rst);
        $countarray = count($_FILES['image']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['image']['name'][$i];
            $temp = $files['image']['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/images/' . $fileName;
            move_uploaded_file($temp, $destination);
        }

//Uploading Header file to database and its destination

        $this->executeQry("insert into " . TBL_LAYOUTS_MANAGE . " set tem_id = '" . $post['template'] . "', lout_id = '" . $post['layouts'] . "',file = '" . $files['headerFile']['name'] . "',header_image='" . $files['headerImage']['name'] . "',height = '" . $post['headerHeight'] . "',is_header='1'");
        $fileName = $files['headerFile']['name'];
        $temp = $files['headerFile']['tmp_name'];
        $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/' . $fileName;
        move_uploaded_file($temp, $destination);
        $fileName = $files['headerImage']['name'];
        $temp = $files['headerImage']['tmp_name'];
        $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/templates/' . $fileName;
        move_uploaded_file($temp, $destination);

//Uploading section files and section thumb image in both database and its destination

        $len = count($all[0]);
        for ($i = 0; $i < $len; $i++) {
            $this->executeQry("insert into " . TBL_SECTION_MANAGE . " set tem_id = '" . $post['template'] . "', lout_id = '" . $post['layouts'] . "',file = '" . $all[1]['name'][$i] . "',height = '" . $all[0][$i] . "',image_name='" . $all[2]['name'][$i] . "',section_index='$i'");
            //uploding section file
            $fileName = $all[1]['name'][$i];
            $temp = $all[1]['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/' . $fileName;
            move_uploaded_file($temp, $destination);
            //uploding section Image
            $fileName = $all[2]['name'][$i];
            $temp = $all[2]['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/templates/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
//-----------------------------------------------------------Json file writing starts here--------------------------------------------
        $this->writeJason($post, $file);




//--------------------------------------------------------------------------------------------------------------------------------------        


        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Information has been added successfully.");

        header("Location:uploadLayout.php");
        exit;
    }

    function editUploadLayoutFile($post, $files) {

        $all = array($post['htmlSecHeight'], $files['htmlSecFile'], $files['htmlSecThumb']);

//        echo"<pre>";
//        print_r($post);
//        die;

        $sql = "select a.*,b.* from " . TBL_TEMPLATES . " as a  join " . TBL_LAYOUTS . " as b on a.id=b.tem_id and b.id='" . $post['layouts'] . "'";
        $rst = $this->executeQry($sql);
        $line = $this->getResultObject($rst);
        $countarray = count($_FILES['image']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['image']['name'][$i];
            $temp = $files['image']['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/images/' . $fileName;
            move_uploaded_file($temp, $destination);
        }

//Uploading Header file to database and its destination folder
        if ($files['headerFile']['name']) {
            $headerFileName = $this->fetchValue(TBL_LAYOUTS_MANAGE, "file", " id = '" . $post['layouts'] . "'");
            unlink('../templates/' . $templateName . '/' . $line->layout_name . '/' . $headerFileName);
            $this->executeQry("update " . TBL_LAYOUTS_MANAGE . " set file = '" . $files['headerFile']['name'] . "' where lout_id='" . $post['layouts'] . "'");
            $fileName = $files['headerFile']['name'];
            $temp = $files['headerFile']['tmp_name'];
            $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
        if ($files['headerImage']['name']) {
            $headerImageName = $this->fetchValue(TBL_LAYOUTS_MANAGE, "header_image", " id = '" . $post['layouts'] . "'");
            unlink('../templates/' . $templateName . '/' . $line->layout_name . '/templates/' . $headerImageName);
            $this->executeQry("update " . TBL_LAYOUTS_MANAGE . " set header_image = '" . $files['headerFile']['name'] . "' where lout_id='" . $post['layouts'] . "'");
            $fileName = $files['headerImage']['name'];
            $temp = $files['headerImage']['tmp_name'];
            $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/templates/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
        $this->executeQry("update " . TBL_LAYOUTS_MANAGE . " set height = '" . $post['headerHeight'] . "' where lout_id='" . $post['layouts'] . "'");


//Uploading section files and section thumb image in both database and its destination folder


        $rst1 = $this->executeQry("select id,file,image_name from " . TBL_SECTION_MANAGE . " where lout_id='" . $post['layouts'] . "'");
        $k = 0;
        while ($line1 = $this->getResultObject($rst1)) {

            //uploding section file
            if ($files['htmlSecFile']['name'][$line1->id]) {
                $fileName = $files['htmlSecFile']['name'][$line1->id];
                unlink('../templates/' . $line->t_name . '/' . $line->layout_name . '/' . $line1->file);
                $this->executeQry("update " . TBL_SECTION_MANAGE . " set file = '" . $fileName . "' where id='" . $line1->id . "'");
                $temp = $files['htmlSecFile']['tmp_name'][$line1->id];
                $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/' . $fileName;
                move_uploaded_file($temp, $destination);
            }

            //uploding section Image
            if ($files['htmlSecThumb']['name'][$line1->id]) {
                $fileName = $files['htmlSecThumb']['name'][$line1->id];
                unlink('../templates/' . $line->t_name . '/' . $line->layout_name . '/templates/' . $line1->image_name);
                $this->executeQry("update " . TBL_SECTION_MANAGE . " set image_name = '" . $fileName . "' where id='" . $line1->id . "'");
                $temp = $files['htmlSecThumb']['tmp_name'][$line1->id];
                $destination = '../templates/' . $line->t_name . '/' . $line->layout_name . '/templates/' . $fileName;
                move_uploaded_file($temp, $destination);
            }
            $this->executeQry("update " . TBL_SECTION_MANAGE . " set height = '" . $post['htmlSecHeight'][$k] . "' where id='" . $line1->id . "'");
            $k++;
        }
/////////////////////////////////////////////////////////
        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Information has been Edited successfully.");
        $id = base64_encode($post['layouts']);
        header("Location:editUploadLayout.php?id=$id");
        exit;
    }

    function validationforUploadLayout($post, $files, $forEditOrAdd = '') { //print_r($files);die;
        $validateField = new validationclass();
        if ($forEditOrAdd == '') {
            $validateField->fnAdd("template", $post["template"], "req", "Please select Template.");
            $layout = $post['layouts'];
            if ($layout[0] == '') {
                $validateField->fnAdd("layouts", $layout[0], "req", "Please enter layout.");
            }
        }
        $validateField->fnAdd("headerHeight", $post["headerHeight"], "req", "Please enter Height.");
        $validateField->fnAdd("headerHeight", $post["headerHeight"], "num", "Please enter valid Height.");
        $countarray = count($files['image']['name']);

        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['image']['name'][$i];
            $extension = findexts($fileName);
            $extension = strtolower($extension);
            if ($forEditOrAdd == '')
                $ext_array = array('jpg', 'jpeg', 'png');
            else
                $ext_array = array('jpg', 'jpeg', 'png', '');
            if (!in_array($extension, $ext_array)) {
                $fileName = '';
                $validateField->fnAdd("image", $fileName, "req", "please select image Files.");
            }
        }

        $fileName = $files['headerFile']['name'];
        $extension = findexts($fileName);
        $extension = strtolower($extension);
        $ext_array = array('html', 'htm', '');
        if ($forEditOrAdd == '')
            $ext_array = array('html', 'htm');
        else
            $ext_array = array('html', 'htm', '');
        if (!in_array($extension, $ext_array)) {
            $fileName = '';
            $validateField->fnAdd("headerFile", $fileName, "req", "please select  html files.");
        }


        $fileName = $files['headerImage']['name'];
        $extension = findexts($fileName);
        $extension = strtolower($extension);

        if ($forEditOrAdd == '')
            $ext_array = array('jpg', 'jpeg', 'png');
        else
            $ext_array = array('jpg', 'jpeg', 'png', '');
        if (!in_array($extension, $ext_array)) {
            $fileName = '';
            $validateField->fnAdd("headerImage", $fileName, "req", "please select image files.");
        }

        $arr_error = $validateField->fnValidate();
        $str_validate = (count($arr_error)) ? 0 : 1;

        $arr_error['template'] = $validateField->fnGetErr($arr_error['template']);
        $arr_error['image'] = $validateField->fnGetErr($arr_error['image']);
        $arr_error['headerFile'] = $validateField->fnGetErr($arr_error['headerFile']);
        $arr_error['layouts'] = $validateField->fnGetErr($arr_error['layouts']);
        $arr_error['headerHeight'] = $validateField->fnGetErr($arr_error['headerHeight']);
        $arr_error['headerImage'] = $validateField->fnGetErr($arr_error['headerImage']);

        $arr_error['ERROR'] = $str_validate;
        //print_r($arr_error);die;
        return $arr_error;
    }

    function writeJason($post, $files) {
        echo'<pre>';
        print_r($files);
        print_r($post);
        //die;
$sql = "select a.*,b.* from " . TBL_TEMPLATES . " as a  join " . TBL_LAYOUTS . " as b on a.id=b.tem_id and b.id='" . $post['layouts'] . "'";
        $rst = $this->executeQry($sql);
        $line = $this->getResultObject($rst);
        $sitepath = "http://norefresh.thesparxitsolutions.com/raushan/coreadmin/";
       $count= count($files['htmlSecFile']['name']);
       for($i=0;$i<$count;$i++){
           
       }
        
        
        

        $array = array();

        $array = array($line->t_name.'/'.$line->layout_name => array(
                'Headers' => array(
                    0 => array(
                        'url' => $sitepath.'admin/templates/'.$line->t_name.'/'.$line->layout_name.'/'.$files['headerFile']['name'],
                        'height' => $post['headerHeight'],
                        'thumbnail' => $sitepath.'admin/templates/'.$line->t_name.'/'.$line->layout_name.'/templates/'.$files['headerImage']['name']
                    )
                ), //close Headers
                'ContentSections' => array(
                    0 => array(
                        'url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'),
                    1 => array('url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'),
                    2 => array('url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'),
                    3 => array('url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'),
                    4 => array('url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'),
                    5 => array('url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'),
                ), // close ContentSections 
                'Footer' => array(0 => array(
                        'url' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html',
                        'height' => '696',
                        'thumbnail' => 'http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png'
                    )
                )
            ) // close AirDev/layout-1  of 1 index 
        ); // close Main array

        echo "<pre>";

        print_r($array);
        echo "</pre>";
        echo json_encode($array);die;
    }

}
