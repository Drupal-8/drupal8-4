 <?php
 
 ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$id=$_GET['id'];
$fileObj= new EditFiles();
        
            $fileObj->Write('1-2-Y2xpZW50cy5odG1s');
      
        ?>  
