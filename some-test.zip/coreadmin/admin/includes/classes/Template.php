<?php

session_start();

class Template extends MySqlDriver {

    function __construct() {
        $this->obj = new MySqlDriver;
    }

    function allTemplateDetailsInformation($id) {
        $query = "select * from " . TBL_TEMPLATES . " where 1=1  ";
        $sql = $this->executeQry($query);
        $num = $this->getTotalRow($sql);
        $menuObj = new Menu();
        $page = $_REQUEST['page'] ? $_REQUEST['page'] : 1;
        //echo $page;
        if ($num > 0) {
            $genTable = '';
            //-------------------------Paging------------------------------------------------			
            $paging = $this->paging($query);
            $this->setLimit($_GET['limit']);
            $recordsPerPage = $this->getLimit();
            $offset = $this->getOffset($_GET["page"]);
            $this->setStyle("redheading");
            $this->setActiveStyle("smallheading");
            $this->setButtonStyle("boldcolor");
            $currQueryString = $this->getQueryString();
            $this->setParameter($currQueryString);
            $totalrecords = $this->numrows;
            $currpage = $this->getPage();
            $totalpage = $this->getNoOfPages();
            $pagenumbers = $this->getPageNo();
            //-------------------------Paging------------------------------------------------

            $orderby = $_GET[orderby] ? $_GET[orderby] : "t_name";
            $order = $_GET[order] ? $_GET[order] : "ASC";

            $query .= " ORDER BY $orderby $order LIMIT " . $offset . ", " . $recordsPerPage;
            // echo $query;
            $rst = $this->executeQry($query);
            $row = $this->getTotalRow($rst);

            if ($row > 0) {
                $i = 1;
                while ($line = $this->getResultObject($rst)) {
                    $highlight = $i % 2 == 0 ? "main-body-bynic" : "main-body-bynic2";

                    $genTable .= '<tr>
									<th>' . $i . '</th>
									<td>' . $line->t_name . '</td>';

                    $genTable .= '<td>';
                    $genTable .= '<a class="i_pencil edit" href="editLandingPage.php?id=' . base64_encode($line->id) . '&page=' . $page . '">Edit</a>';
                    $genTable .= '</td>';
                    $genTable .= '<td>';
                    //if($menuObj->checkEditPermission("manageBlocks.php")){
                    $genTable .= '<a class="i_pencil edit" href="editTemplate.php?id=' . base64_encode($line->id) . '&page=' . $page . '">Edit</a>';
                    //}
                    $genTable .= '</td>';
                    $genTable .= '<td>';
                    if ($_SESSION['ADMIN_ID'] == 1) {
                        $genTable .= "<a class='i_trashcan edit' href='javascript:void(0);'  onClick=\"if(confirm('Are you sure to delete this Record Containts?')){window.location.href='pass.php?action=template&type=delete&id=" . $line->id . "&pageId=" . base64_encode($id) . "&page=$page'}else{}\" >Delete</a>";
                    }
                    $genTable .= '</td>';

                    $genTable .= '</tr>';
                    $i++;
                }
                switch ($recordsPerPage) {
                    case 10:
                        $sel1 = "selected='selected'";
                        break;
                    case 20:
                        $sel2 = "selected='selected'";
                        break;
                    case 30:
                        $sel3 = "selected='selected'";
                        break;
                    case $this->numrows:
                        $sel4 = "selected='selected'";
                        break;
                }
                $currQueryString = $this->getQueryString();
                $limit = basename($_SERVER['PHP_SELF']) . "?" . $currQueryString;
                $genTable.="<div style='overflow:hidden; margin:0px 0px 0px 50px;'><table border='0' width='88%' height='50'>
					 <tr><td align='left' width='300' class='page_info' 'style=margin-left=20px;'>
					 Display <select name='limit' id='limit' onchange='pagelimit(\"$limit\");' class='page_info'>
					 <option value='10' $sel1>10</option>
					 <option value='20' $sel2>20</option>
					 <option value='30' $sel3>30</option> 
					 <option value='" . $totalrecords . "' $sel4>All</option>  
					   </select> Records Per Page
					</td><td align='center' class='page_info'><input type='hidden' name='page' value='" . $currpage . "'></td><td class='page_info' align='center' width='200'>Total " . $totalrecords . " records found</td><td width='0' align='right'>" . $pagenumbers . "</td></tr></table></div>";
            }
        } else {
            $genTable = '<div>&nbsp;</div><div class="Error-Msg">Sorry no records found</div>';
        }
        return $genTable;
    }

    function deleteRecord($get) {
        $templateName = $this->fetchValue(TBL_TEMPLATES, "t_name", " id = '$get[id]'");
        Template::deleteDir('../templates/' . $templateName);
        $this->deleteval(TBL_TEMPLATES, " id = '$get[id]'");
        $this->deleteval(TBL_LAYOUTS, " tem_id = '$get[id]'");
        $this->deleteval(TBL_LAYOUTS_MANAGE, " tem_id = '$get[id]'");
        $this->deleteval(TBL_SECTION_MANAGE, " tem_id = '$get[id]'");
        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your Information has been deleted successfully!!!");
        echo "<script language=javascript>window.location.href='manageTemplates.php';</script>";
    }

    public static function deleteDir($dirPath) {
        if (!is_dir($dirPath)) {
            throw new InvalidArgumentException("$dirPath must be a directory");
        }
        if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
            $dirPath .= '/';
        }
        $files = glob($dirPath . '*', GLOB_MARK);
        foreach ($files as $file) {
            if (is_dir($file)) {
                self::deleteDir($file);
            } else {
                unlink($file);
            }
        }
        rmdir($dirPath);
    }

    function allLayoutDetailsInformation($id) {

        $query = "select * from " . TBL_LAYOUTS . " where tem_id='$id'";

        //echo $query;
        $sql = $this->executeQry($query);
        $num = $this->getTotalRow($sql);
        $menuObj = new Menu();
        $page = $_REQUEST['page'] ? $_REQUEST['page'] : 1;
        //echo $page;
        if ($num > 0) {
            $genTable = '';
            //-------------------------Paging------------------------------------------------			
            $paging = $this->paging($query);
            $this->setLimit($_GET['limit']);
            $recordsPerPage = $this->getLimit();
            $offset = $this->getOffset($_GET["page"]);
            $this->setStyle("redheading");
            $this->setActiveStyle("smallheading");
            $this->setButtonStyle("boldcolor");
            $currQueryString = $this->getQueryString();
            $this->setParameter($currQueryString);
            $totalrecords = $this->numrows;
            $currpage = $this->getPage();
            $totalpage = $this->getNoOfPages();
            $pagenumbers = $this->getPageNo();
            //-------------------------Paging------------------------------------------------

            $orderby = $_GET[orderby] ? $_GET[orderby] : "layout_name";
            $order = $_GET[order] ? $_GET[order] : "ASC";

            $query .= " ORDER BY $orderby $order LIMIT " . $offset . ", " . $recordsPerPage;
            // echo $query;
            $rst = $this->executeQry($query);
            $row = $this->getTotalRow($rst);

            if ($row > 0) {
                $i = 1;
                while ($line = $this->getResultObject($rst)) {
                    $highlight = $i % 2 == 0 ? "main-body-bynic" : "main-body-bynic2";

                    $genTable .= '<tr>
									<th>' . $i . '</th>
									<td>' . $line->layout_name . '</td>';


                    $genTable .= '<td><a class="i_pencil edit" href="editLayoutFiles.php?id=' . base64_encode($line->id) . '&page=' . $page . '">Edit</a></td>';
                    $genTable .= '<td>';
                    //if($menuObj->checkEditPermission("manageBlocks.php")){
                    $genTable .= '<a class="i_pencil edit" href="editUploadLayout.php?id=' . base64_encode($line->id) . '&page=' . $page . '">Edit</a>';
                    //}
                    $genTable .= '</td>';
                    $genTable .= '<td>';
                    if ($_SESSION['ADMIN_ID'] == 1) {
                        $genTable .= "<a class='i_trashcan edit' href='javascript:void(0);'  onClick=\"if(confirm('Are you sure to delete this Record Containts?')){window.location.href='pass.php?action=layout&type=delete&id=" . $line->id . "&pageId=" . base64_encode($id) . "&page=$page'}else{}\" >Delete</a>";
                    }
                    $genTable .= '</td>';

                    $genTable .= '</tr>';
                    $i++;
                }
                switch ($recordsPerPage) {
                    case 10:
                        $sel1 = "selected='selected'";
                        break;
                    case 20:
                        $sel2 = "selected='selected'";
                        break;
                    case 30:
                        $sel3 = "selected='selected'";
                        break;
                    case $this->numrows:
                        $sel4 = "selected='selected'";
                        break;
                }
                $currQueryString = $this->getQueryString();
                $limit = basename($_SERVER['PHP_SELF']) . "?" . $currQueryString;
                $genTable.="<div style='overflow:hidden; margin:0px 0px 0px 50px;'><table border='0' width='88%' height='50'>
					 <tr><td align='left' width='300' class='page_info' 'style=margin-left=20px;'>
					 Display <select name='limit' id='limit' onchange='pagelimit(\"$limit\");' class='page_info'>
					 <option value='10' $sel1>10</option>
					 <option value='20' $sel2>20</option>
					 <option value='30' $sel3>30</option> 
					 <option value='" . $totalrecords . "' $sel4>All</option>  
					   </select> Records Per Page
					</td><td align='center' class='page_info'><input type='hidden' name='page' value='" . $currpage . "'></td><td class='page_info' align='center' width='200'>Total " . $totalrecords . " records found</td><td width='0' align='right'>" . $pagenumbers . "</td></tr></table></div>";
            }
        } else {
            $genTable = '<div>&nbsp;</div><div class="Error-Msg">Sorry no records found</div>';
        }
        return $genTable;
    }

    function deleteRecordLayout($get) {
        $qry = $this->executeQry("select tem_id,layout_name from " . TBL_LAYOUTS . " where id= '$get[id]' ");
        $line = $this->getResultObject($qry);
        $templateName = $this->fetchValue(TBL_TEMPLATES, "t_name", " id = '$line->tem_id'");
        Template::deleteDir('../templates/' . $templateName . '/' . $line->layout_name);
        $this->deleteval(TBL_LAYOUTS, " id = '$get[id]'");

        $this->deleteval(TBL_LAYOUTS_MANAGE, "lout_id = '$get[id]'");
        $this->deleteval(TBL_SECTION_MANAGE, "lout_id = '$get[id]'");
        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your Information has been deleted successfully!!!");
        echo "<script language=javascript>window.location.href='manageLayouts.php';</script>";
    }

    function getAllAdmin($users = '') {
        $sql = "SELECT id, username from " . TBL_ADMINLOGIN . " where status='1' and id!='1'";
        $rst = $this->executeQry($sql);
        $tbl = '<select name="user[]" multiple size="3" style="width:250px;" >';
        while ($line = $this->getResultObject($rst)) {
            $selected = '';
            if ($users == '') {
                $tbl.='<option value="' . $line->id . '">' . $line->username . '</option>';
            } else {
                $pos = strpos($users, $line->id);

                if ($pos !== false) {
                    $selected = 'selected';
                }
                $tbl.='<option value="' . $line->id . '" ' . $selected . '>' . $line->username . '</option>';
            }
        }
        $tbl.='</select>';
        return $tbl;
    }

    function getLayOuts($id) {
        $sql = $this->executeQry("select * from " . TBL_LAYOUTS . " where tem_id='$id'");
        $i = 1;
        while ($line = $this->getResultObject($sql)) {
            $tbl.='<label for="layout" >Layout' . $i . '</label>
                            <div><input type="text" name="oldLayout[]"  value="' . $line->layout_name . '"  disabled/></div>';
            $i++;
        }
        return $tbl;
    }

    function addTemplet($post) { //print_r($post);die;
        $USERS = implode(',', $post['user']);

        $sql1 = $this->executeQry("insert into " . TBL_TEMPLATES . " set t_name = '" . $post['templateName'] . "', online_pcode = '" . $post['onlineCode'] . "',offline_pcode = '" . $post['offlineCode'] . "',users = '$USERS'");

        if (!file_exists("../templates"))
            mkdir("../templates", 0777);
        mkdir("../templates/" . $post['templateName'], 0777);
        $inserted_id = $this->insert_id();
        $layouts = $post['layout'];

        foreach ($layouts as $layout) {

            $query = $this->executeQry("insert into  " . TBL_LAYOUTS . " set tem_id = '$inserted_id',layout_name='$layout' ");
            mkdir("../templates/" . $post['templateName'] . '/' . $layout, 0777) or die('cant find path');
            mkdir("../templates/" . $post['templateName'] . '/' . $layout . '/templates', 0777) or die('cant find path');
            mkdir("../templates/" . $post['templateName'] . '/' . $layout . '/images', 0777) or die('cant find path');
            $content = 'var _Elements = {"' . $post['templateName'] . '/' . $layout . '": {}}';
            $fp = fopen('../templates/' . $post['templateName'] . '/' . $layout . '/elements.json', 'wb');
            fwrite($fp, $content);
            fclose($fp);
        }
        mkdir("../templates/" . $post['templateName'] . '/assets', 0777) or die('cant find path');
        mkdir("../templates/" . $post['templateName'] . '/assets/images', 0777) or die('cant find path');
        mkdir("../templates/" . $post['templateName'] . '/assets/js', 0777) or die('cant find path');
        mkdir("../templates/" . $post['templateName'] . '/assets/css', 0777) or die('cant find path');

        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Information has been added successfully.");

        header("Location:addtemplate.php");
        exit;
    }

    function editTemplet($post) {
        $USERS = implode(',', $post['user']);

        $sql1 = $this->executeQry("update " . TBL_TEMPLATES . "  set    online_pcode = '" . $post['onlineCode'] . "',offline_pcode = '" . $post['offlineCode'] . "',users = '$USERS' where id='" . $post['id'] . "'");
        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Information has been added successfully.");
        $id = base64_encode($post['id']);
        header("Location:editTemplate.php?id=$id");
        exit;
    }

    function getTempName($name) {
        $sql = "SELECT t_name  FROM " . TBL_TEMPLATES . " WHERE t_name='$name'";

        $rst = $this->executeQry($sql);
        if ($this->getTotalRow($rst) > 0) {
            return "template already exists";
        }
    }

    function getAllTemplates($post) {
        $sql = "SELECT id, t_name from " . TBL_TEMPLATES;
        $rst = $this->executeQry($sql);
        $tbl = '<select name="template" style="width:250px;" id="layouts"><option value="">select template</option>';
        while ($line = $this->getResultObject($rst)) {
            $selected = '';
            if ($line->id == $post['template'])
                $selected = 'selected';
            $tbl.='<option value="' . $line->id . '" ' . $selected . '>' . $line->t_name . '</option>';
        }
        $tbl.='</select>';
        return $tbl;
    }

    function getRelatedlayouts($id, $layId = '') {

        if ($id == '') {
            $tbl = '<select name="layouts"><option value="">select Template First</option></select>';
            return $tbl;
        }
        $sql = "SELECT id, layout_name from " . TBL_LAYOUTS . " where tem_id='$id'";
        $rst = $this->executeQry($sql);
        $tbl = '<select name="layouts"><option value="">select layout</option>';
        while ($line = $this->getResultObject($rst)) {
            $selected = '';
            if ($line->id == $layId)
                $selected = 'selected';
            $tbl.='<option value="' . $line->id . '" ' . $selected . '>' . $line->layout_name . '</option>';
        }
        $tbl.='</select>';
        return $tbl;
    }

    function uploadTemplateFile($post, $files, $iseditOrAdd = '') {
        $sql = "SELECT  t_name from " . TBL_TEMPLATES . "  where id='" . $post['template'] . "'";
        $rst = $this->executeQry($sql);
        $line = $this->getResultObject($rst);

        $countarray = count($_FILES['image']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['image']['name'][$i];
            $temp = $files['image']['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/assets/images/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
        $countarray = count($_FILES['js']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['js']['name'][$i];
            $temp = $files['js']['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/assets/js/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
        $countarray = count($_FILES['css']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['css']['name'][$i];
            $temp = $files['css']['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/assets/css/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
        $countarray = count($_FILES['htmls']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['htmls']['name'][$i];
            $temp = $files['htmls']['tmp_name'][$i];
            $destination = '../templates/' . $line->t_name . '/' . $fileName;
            move_uploaded_file($temp, $destination);
        }
        if ($iseditOrAdd == '') {
            $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Information has been added successfully.");

            header("Location:upload-landing.php");
            exit;
        } else {
            $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Information has been edited successfully.");
            $id = base64_encode($post['template']);
            header("Location:editLandingPage.php?id=$id");
            exit;
        }
    }

    function getResult($id) {
        $qry = $this->executeQry("select * from " . TBL_TEMPLATES . "  where id='$id'");
        $line = $this->getResultObject($qry);
        return $line;
    }

    function getResultLayout($id) {//echo "select a.layout_name,b.* ,c.height,c.file from " . TBL_LAYOUTS . " a join " . TBL_TEMPLATES . " b on b.id=a.tem_id join ".TBL_LAYOUTS_MANAGE." c on b.id=c.tem_id and a.id='$id' and is_header='1'";die;
        $qry = $this->executeQry("select a.layout_name,b.* ,c.height,c.file from " . TBL_LAYOUTS . " a join " . TBL_TEMPLATES . " b on b.id=a.tem_id join " . TBL_LAYOUTS_MANAGE . " c on b.id=c.tem_id and a.id='$id' and is_header='1'");
        $line = $this->getResultObject($qry);
        return $line;
    }

    function getResultLayoutHeaders($id) {
        $result = array();
        $query = $this->executeQry("select * from " . TBL_SECTION_MANAGE . " where lout_id='$id'");
        while ($line = $this->getResultRow($query, 'MYSQL_ASSOC')) {
            $result[] = $line;
        }
        return $result;
    }

    function validationforUpload($post, $files) {
        require_once('validation_class.php');
        $validateField = new validationclass();
        $validateField->fnAdd("template", $_POST["template"], "req", "Please Select Template.");
        $filename = $files['image']['name'];
        if ($filename[0] == '') {
            $validateField->fnAdd("file", $filename, "req", "Select atleast a image.");
        }

        $validateField->fnAdd("file", $filename, "req", "Select a file.");
        $extension = findexts($filename);
        $extension = strtolower($extension);

        $ext_array = array('zip');
        if (!in_array($extension, $ext_array)) {
            $filename = '';
            $validateField->fnAdd("file", $filename, "req", "please select only .zip file.");
        }


        $arr_error = $validateField->fnValidate();
        $str_validate = (count($arr_error)) ? 0 : 1;

        $arr_error['template'] = $validateField->fnGetErr($arr_error['template']);

        $arr_error['ERROR'] = $str_validate;

        return $arr_error;
    }

    function validationAddTemp($post, $isEdit = '') {
        require_once('validation_class.php');
        $validateField = new validationclass();
        if ($isEdit == '') {
            $validateField->fnAdd("templateName", $_POST["templateName"], "req", "Please input Template.");
            $layout = $post['layout'];

            if ($layout[0] == '') {
                $validateField->fnAdd("layout", $layout[0], "req", "Please select layout.");
            }
        }

        $validateField->fnAdd("offlineCode", $_POST["offlineCode"], "req", "Please enter offline code.");
        $validateField->fnAdd("onlineCode", $_POST["onlineCode"], "req", "Please enter onlineCode code.");

        $arr_error = $validateField->fnValidate();
        $str_validate = (count($arr_error)) ? 0 : 1;

        $arr_error['templateName'] = $validateField->fnGetErr($arr_error['templateName']);
        $arr_error['offlineCode'] = $validateField->fnGetErr($arr_error['offlineCode']);
        $arr_error['onlineCode'] = $validateField->fnGetErr($arr_error['onlineCode']);
        $arr_error['layout'] = $validateField->fnGetErr($arr_error['layout']);

        $arr_error['ERROR'] = $str_validate;

        return $arr_error;
    }

    function validationforlanding($post, $files, $forEditOrAdd = '') { //print_r($files);die;
        $validateField = new validationclass();
        if ($forEditOrAdd == '')
            $validateField->fnAdd("template", $post["template"], "req", "Please select Template.");

        $countarray = count($files['image']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['image']['name'][$i];
            $extension = findexts($fileName);
            $extension = strtolower($extension);
            $ext_array = array('jpg', 'jpeg', 'png', '');
            if (!in_array($extension, $ext_array)) {
                $fileName = '';
                $validateField->fnAdd("image", $fileName, "req", "please select image Files.");
            }
        }

        $countarray = count($files['js']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['js']['name'][$i];
            $extension = findexts($fileName);
            $extension = strtolower($extension);
            $ext_array = array('js', '');
            if (!in_array($extension, $ext_array)) {
                $fileName = '';
                $validateField->fnAdd("js", $fileName, "req", "please select only Javascript files.");
            }
        }
        $countarray = count($files['css']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['css']['name'][$i];
            $extension = findexts($fileName);
            $extension = strtolower($extension);
            $ext_array = array('css', '');
            if (!in_array($extension, $ext_array)) {
                $fileName = '';
                $validateField->fnAdd("css", $fileName, "req", "please select only css files.");
            }
        }
        $countarray = count($files['htmls']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['htmls']['name'][$i];
            $extension = findexts($fileName);
            $extension = strtolower($extension);
            $ext_array = array('html', 'htm', '');
            if (!in_array($extension, $ext_array)) {
                $fileName = '';
                $validateField->fnAdd("htmls", $fileName, "req", "please select only html files.");
            }
        }



        $arr_error = $validateField->fnValidate();
        $str_validate = (count($arr_error)) ? 0 : 1;

        $arr_error['template'] = $validateField->fnGetErr($arr_error['template']);
        $arr_error['image'] = $validateField->fnGetErr($arr_error['image']);
        $arr_error['js'] = $validateField->fnGetErr($arr_error['js']);
        $arr_error['css'] = $validateField->fnGetErr($arr_error['css']);
        $arr_error['htmls'] = $validateField->fnGetErr($arr_error['htmls']);

        $arr_error['ERROR'] = $str_validate;
        //print_r($arr_error);die;
        return $arr_error;
    }

}
