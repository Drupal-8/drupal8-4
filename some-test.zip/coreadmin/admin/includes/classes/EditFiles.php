<?php

session_start();

class EditFiles extends MySqlDriver {

    function __construct() {
        $this->obj = new MySqlDriver;
    }
    
    function allHtmlFilesInformation($id){
        $query = "SELECT file,height,tem_id,lout_id FROM ".TBL_SECTION_MANAGE."  where lout_id='$id' UNION SELECT file,height,tem_id,lout_id FROM  ".TBL_LAYOUTS_MANAGE." where lout_id='$id'";
       
        //echo $query;
        $sql = $this->executeQry($query);
        $num = $this->getTotalRow($sql);
        $menuObj = new Menu();
        $page = $_REQUEST['page'] ? $_REQUEST['page'] : 1;
        //echo $page;
        if ($num > 0) {
            $genTable = '';
            //-------------------------Paging------------------------------------------------			
            $paging = $this->paging($query);
            $this->setLimit($_GET['limit']);
            $recordsPerPage = $this->getLimit();
            $offset = $this->getOffset($_GET["page"]);
            $this->setStyle("redheading");
            $this->setActiveStyle("smallheading");
            $this->setButtonStyle("boldcolor");
            $currQueryString = $this->getQueryString();
            $this->setParameter($currQueryString);
            $totalrecords = $this->numrows;
            $currpage = $this->getPage();
            $totalpage = $this->getNoOfPages();
            $pagenumbers = $this->getPageNo();
            //-------------------------Paging------------------------------------------------

            $orderby = $_GET[orderby] ? $_GET[orderby] : "file";
            $order = $_GET[order] ? $_GET[order] : "ASC";

            $query .= " ORDER BY $orderby $order LIMIT " . $offset . ", " . $recordsPerPage;
            // echo $query;
            $rst = $this->executeQry($query);
            $row = $this->getTotalRow($rst);

            if ($row > 0) {
                $i = 1;
                while ($line = $this->getResultObject($rst)) {
                    $name=  base64_encode($line->file);
                    $arr=array($line->tem_id,$line->lout_id,$name);
                    $mixed=  implode('-', $arr);
                    $highlight = $i % 2 == 0 ? "main-body-bynic" : "main-body-bynic2";

                    $genTable .= '<tr>
									<th>' . $i . '</th>
									<td>' . $line->file . '</td>';
                    
                    
                    $genTable .= '<td><a class="i_pencil edit" href="editFile.php?id=' . $mixed . '&page=' . $page . '">Edit</a></td>';
                    
                    $genTable .= '<td>';
					if($_SESSION['ADMIN_ID']==1){
                    $genTable .= "<a class='i_trashcan edit' href='javascript:void(0);'  onClick=\"if(confirm('Are you sure to delete this Record Containts?')){window.location.href='pass.php?action=layout&type=delete&id=" . $line->id . "&pageId=" . base64_encode($id) . "&page=$page'}else{}\" >Delete</a>";
                    }
                    $genTable .= '</td>';

                    $genTable .= '</tr>';
                    $i++;
                }
                switch ($recordsPerPage) {
                    case 10:
                        $sel1 = "selected='selected'";
                        break;
                    case 20:
                        $sel2 = "selected='selected'";
                        break;
                    case 30:
                        $sel3 = "selected='selected'";
                        break;
                    case $this->numrows:
                        $sel4 = "selected='selected'";
                        break;
                }
                $currQueryString = $this->getQueryString();
                $limit = basename($_SERVER['PHP_SELF']) . "?" . $currQueryString;
                $genTable.="<div style='overflow:hidden; margin:0px 0px 0px 50px;'><table border='0' width='88%' height='50'>
					 <tr><td align='left' width='300' class='page_info' 'style=margin-left=20px;'>
					 Display <select name='limit' id='limit' onchange='pagelimit(\"$limit\");' class='page_info'>
					 <option value='10' $sel1>10</option>
					 <option value='20' $sel2>20</option>
					 <option value='30' $sel3>30</option> 
					 <option value='" . $totalrecords . "' $sel4>All</option>  
					   </select> Records Per Page
					</td><td align='center' class='page_info'><input type='hidden' name='page' value='" . $currpage . "'></td><td class='page_info' align='center' width='200'>Total " . $totalrecords . " records found</td><td width='0' align='right'>" . $pagenumbers . "</td></tr></table></div>";
            }
        } else {
            $genTable = '<div>&nbsp;</div><div class="Error-Msg">Sorry no records found</div>';
        }
        return $genTable;
    }

    function Read($id) {
        $arr = explode('-', $id);
        $fileName = base64_decode($arr[2]);
        $query = "select a.t_name,b.layout_name FROM " . TBL_TEMPLATES . " as a join " . TBL_LAYOUTS . " as b on a.id=b.tem_id and b.tem_id='$arr[0]' and b.id='$arr[1]' ";
        $sql = $this->executeQry($query);
        $line = $this->getResultObject($sql);

        $file = "../templates/" . $line->t_name . "/" . $line->layout_name . "/" . $fileName;
        //echo $file;
        $fp = fopen($file, "r");
        if (0 == filesize($file)) {
            echo "     file is empty";
        } else {
            while (!feof($fp)) {
                $data = fgets($fp, filesize($file));
                echo $data;
            }
        }
        fclose($fp);
    }

    function Write($id,$files) {  
        $arr = explode('-', $id);
        $fileName = base64_decode($arr[2]);
        $query = "select a.t_name,b.layout_name FROM " . TBL_TEMPLATES . " as a join " . TBL_LAYOUTS . " as b on a.id=b.tem_id and b.tem_id='$arr[0]' and b.id='$arr[1]' ";
        $sql = $this->executeQry($query);
        $line = $this->getResultObject($sql);
        $filename = "../templates/" . $line->t_name . "/" . $line->layout_name . "/" . $fileName;
        // open file 
        $fw = fopen($filename, 'w') or die('Could not open file!');
        // write to file
        $fb = fwrite($fw, stripslashes($_POST["tekst"])) or die('Could not write to file');
        // close file
        $countarray = count($files['image']['name']);
        $newarray = array();
        for ($i = 0; $i < $countarray; $i++) {
            $fileName = $files['image']['name'][$i];
            $temp = $files['image']['tmp_name'][$i];
            $destination = "../templates/" . $line->t_name . "/" . $line->layout_name . "/images/" . $fileName;
            move_uploaded_file($temp, $destination);
        }
        
        $_SESSION['SESS_MSG'] = msgSuccessFail("success", "Page Edited successfully.");
        header("Location:editFile.php?id=$id");
        exit;
    }
    

}
