<?php

session_start();

class Provider extends MySqlDriver {

	function __construct() {
		$this->obj = new MySqlDriver;
	}
        /* display all provider details on manage provider page  */
	function valDetail() {
		$menuObj = new Menu;
		$cond = " 1=1 ";
		if ($_REQUEST['searchtxt'] && $_REQUEST['searchtxt'] != 'searchtext') {
			$searchtxt = $_REQUEST['searchtxt'];
			$cond .= " AND ( " . TBL_PROVIDER . ".`emailId` LIKE '%$searchtxt%')  ";
		}
		$query = " SELECT * from " . TBL_PROVIDER . " WHERE $cond ";
		$sql = $this->executeQry($query);
		$num = $this->getTotalRow($sql);
		$page = $_REQUEST['page'] ? $_REQUEST['page'] : 1;
		if ($num > 0) {
			//-------------------------Paging------------------------------------------------
			$paging = $this->paging($query);
			$this->setLimit($_GET[limit]);
			$recordsPerPage = $this->getLimit();
			$offset = $this->getOffset($_GET["page"]);
			$this->setStyle("redheading");
			$this->setActiveStyle("smallheading");
			$this->setButtonStyle("boldcolor");
			$currQueryString = $this->getQueryString();
			$this->setParameter($currQueryString);
			$totalrecords = $this->numrows;
			$currpage = $this->getPage();
			$totalpage = $this->getNoOfPages();
			$pagenumbers = $this->getPageNo();
			//-------------------------Paging------------------------------------------------
			$orderby = $_GET[orderby] ? $_GET[orderby] : "addDate";
			$order = $_GET[order] ? $_GET[order] : "DESC";
			$query .= " ORDER BY $orderby $order LIMIT " . $offset . ", " . $recordsPerPage;
			$rst = $this->executeQry($query);
			$row = $this->getTotalRow($rst);
			if ($row > 0) {
				$i = 1;
				while ($line = $this->getResultObject($rst)) {
					$highlight = $i % 2 == 0 ? "main-body-bynic" : "main-body-bynic2";
					$div_id = "status" . $line->id;
					if ($line->status == 0)
					$status = "Inactive";
					else
					$status = "Active";

					$genTable .= '<tr class="dragbox-content ' . $highlight . '" id="' . $line->id . '" >';
					$genTable .= '<th><input name="chk[]" value="' . $line->id . '" type="checkbox"></th>';
					$genTable .= '<td>' . $i . '</td>';
					$genTable .= '<td>' . stripslashes($line->providerName) . '</td>';
					$genTable .= '<td style="height:100px;width:100px;">' . '<div><img  src="' . SITEPATH . __PROVIDERTHUMB__ . $line->providerImage . '" name="categoryImage" alt="image" />
            </div></td>';
					$genTable .= '<td><div id="' . $div_id . '" style="cursor:pointer;" onClick="javascript:changeStatus(\'' . $div_id . '\',\'' . $line->id . '\',\'manageprovider\')">' . $status . '</div></td>';
					$genTable .= '<td><a rel="shadowbox;width=705;height=325" title="' . $line->emailId . '" href="viewProvider.php?id=' . base64_encode($line->id) . '&pageId=' . base64_encode($id) . '" title="View"><img src="images/view.png" alt="View" width="16" height="16" border="0" /></a></td>';
					if ($menuObj->checkEditPermission())
					$genTable .= '<td><a class="i_pencil edit" href="editProvider.php?id=' . base64_encode($line->id) . '&page=' . $page . '">' . LANG_EDIT . '</a></td>';
					else {
						$genTable .= '<td>&nbsp;</td>';
					}
					if ($menuObj->checkDeletePermission()) {
						$genTable .= "<td><a class='i_trashcan edit' href='javascript:void(0);'  onClick=\"if(confirm('Are you sure to delete this Query?')){window.location.href='pass.php?action=manageprovider&type=delete&id=" . $line->id . "&page=$page'}else{}\" ><img src='images/drop.png' height='16' width='16' border='0' title='Delete' /></a></td>";
					} else {
						$genTable .= '<td>' . $i . '</td>';
					}
					$genTable .= '</tr>';

					$i++;
				}
				switch ($recordsPerPage) {
					case 10:
						$sel1 = "selected='selected'";
						break;
					case 20:
						$sel2 = "selected='selected'";
						break;
					case 30:
						$sel3 = "selected='selected'";
						break;
					case $this->numrows:
						$sel4 = "selected='selected'";
						break;
				}
				$currQueryString = $this->getQueryString();
				$limit = basename($_SERVER['PHP_SELF']) . "?" . $currQueryString;
				$genTable.="<div style='overflow:hidden; margin:0px 0px 0px 50px;'><table border='0' width='88%' height='50'>
					 <tr><td align='left' width='300' class='page_info' 'style=margin-left=20px;'>
					 Display <select name='limit' id='limit' onchange='pagelimit(\"$limit\");' class='page_info'>
					 <option value='10' $sel1>10</option>
					 <option value='20' $sel2>20</option>
					 <option value='30' $sel3>30</option> 
					 <option value='" . $totalrecords . "' $sel4>All</option>  
					   </select> Records Per Page
					</td><td align='center' class='page_info'><inputtype='hidden' name='page' value='" . $currpage . "'></td><td class='page_info' align='center' width='200'>Total " . $totalrecords . " records found</td><td width='0' align='right'>" . $pagenumbers . "</td></tr></table></div>";
			}
		} else {
			$genTable = '<div>&nbsp;</div><div class="alert i_access_denied red">Sorry no records found</div>';
		}
		return $genTable;
	}
/* changes a provider status  */
	function changeStatus($get) {
		;
		$xmlArr = array();
		$xm = 1;
		$status = $this->fetchValue(TBL_PROVIDER, "status", "1 and id = '$get[id]'");
		if ($status == 1) {
			$stat = 0;
			$status = "Inactive,0";
		} else {
			$stat = 1;
			$status = "Active,1";
		}

		$query = "update " . TBL_PROVIDER . " set status = '$stat', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id = '$get[id]'";
		if ($this->executeQry($query))
		$this->logSuccessFail('1', $query);
		else
		$this->logSuccessFail('0', $query);
		echo $status;
	}
        /* delete a provider   */
	function deleteRecord($get) {
		$xmlArr = array();
		$xm = 1;
		$image_name = $this->fetchValue(TBL_PROVIDER, "providerImage", " id = '" . $get['id'] . "'");

		$OriginalImage = ABSOLUTEPATH . __PROVIDERORIGINAL__ . $image_name;
		$LargeImage = ABSOLUTEPATH . __PROVIDERLARGE__ . $image_name;
		$ThumbImage = ABSOLUTEPATH . __PROVIDERTHUMB__ . $image_name;
		chmod($OriginalImage, 0777);
		chmod($LargeImage, 0777);
		chmod($ThumbImage, 0777);

		@unlink($OriginalImage);
		@unlink($LargeImage);
		@unlink($ThumbImage);

		$query = "delete from " . TBL_PROVIDER . " where id = '" . $get['id'] . "'";
		$this->executeQry($query);
		$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your Information has been deleted successfully!!!");
		echo "<script language=javascript>window.location.href='manageProvider.php?page=$get[page]&limit=$get[limit]';</script>";
	}
        /* add a provider   */
	function addRecord($post, $file = '') {
		$con = "";
		if ($file['providerImage']['name']) {
			$filename = stripslashes($file['providerImage']['name']);
			$extension = findexts($filename);
			$extension = strtolower($extension);

			$image_name = date("Ymdhis") . time() . rand() . '.' . $extension;
			$target = ABSOLUTEPATH . __PROVIDERORIGINAL__ . $image_name;
			if ($this->checkExtensions($extension)) {
				$filestatus = move_uploaded_file($file['providerImage']['tmp_name'], $target);
				chmod($target, 0777);
				if ($filestatus) {
					$imgSource = $target;
					$LargeImage = ABSOLUTEPATH . __PROVIDERLARGE__ . $image_name;
					$ThumbImage = ABSOLUTEPATH . __PROVIDERTHUMB__ . $image_name;
					chmod(ABSOLUTEPATH . __PROVIDERORIGINAL__, 0777);
					chmod(ABSOLUTEPATH . __PROVIDERTHUMB__, 0777);
					$fileSize = $this->findSize('PROVIDER_THUMB_WIDTH', 'PROVIDER_THUMB_HEIGHT', 180, 132);
					exec(IMAGEMAGICPATH . " $imgSource -thumbnail $fileSize $ThumbImage");
					//exec(IMAGEMAGICPATH . " $imgSource -thumbnail $fileSize $LargeImage");
				} else {
					$_SESSION['SESS_MSG'] .= msgSuccessFail('fail', "There is some error to upload flag.!!!");
				}
			} else {
				$_SESSION['SESS_MSG'] .= msgSuccessFail('fail', "This files are not allowed for images.!!!");
			}
		}

		if ($_SESSION['SESS_MSG'] == "") {

			echo $query = "insert into " . TBL_PROVIDER . " set providerName = '" . addslashes($post['providerName']) . "', providerImage='" . $image_name . "', status = '1', addDate = '" . date('Y-m-d') . "', addedBy = '" . $_SESSION['ADMIN_ID'] . "'";

			if ($this->executeQry($query))
			$this->logSuccessFail('1', $query);
			else
			$this->logSuccessFail('0', $query);
			$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your information has been added successfully");
		}
		header('location:addProvider.php');
		exit();
	}
        /* edit  provider details   */
	function editRecord($post, $file = '') {
		$_SESSION['SESS_MSG'] = "";
		#-------for image---------
		if ($file['providerImage']['name']) {
			$filename = stripslashes($file['providerImage']['name']);
			$extension = findexts($filename);
			$extension = strtolower($extension);

			$image_name = date("Ymdhis") . time() . rand() . '.' . $extension;
			$target = ABSOLUTEPATH . __PROVIDERORIGINAL__ . $image_name;

			if ($this->checkExtensions($extension)) {
				$filestatus = move_uploaded_file($file['providerImage']['tmp_name'], $target);
				chmod($target, 0777);
				if ($filestatus) {
					$imgSource = $target;
					$LargeImage = ABSOLUTEPATH . __PROVIDERLARGE__ . $image_name;
					$ThumbImage = ABSOLUTEPATH . __PROVIDERTHUMB__ . $image_name;
					chmod($LargeImage, 0777);
					chmod($ThumbImage, 0777);

					$fileSize = $this->findSize('PROVIDER_THUMB_WIDTH', 'PROVIDER_THUMB_HEIGHT', 180, 132);
					// exec(IMAGEMAGICPATH . " $imgSource -thumbnail $fileSize $LargeImage");
					exec(IMAGEMAGICPATH . " $imgSource -thumbnail $fileSize $ThumbImage");
					$prevCategoryImage = $this->fetchValue(TBL_PROVIDER, "providerImage", "1 and id = '$post[id]'");
					@unlink(ABSOLUTEPATH . __PROVIDERORIGINAL__ . $prevCategoryImage);
					@unlink(ABSOLUTEPATH . __PROVIDERLARGE__ . $prevCategoryImage);
					@unlink(ABSOLUTEPATH . __PROVIDERTHUMB__ . $prevCategoryImage);
					$query = "update " . TBL_PROVIDER . " set providerImage = '$image_name', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id = '$post[id]'";
					if ($this->executeQry($query))
					$this->logSuccessFail('1', $query);
					else
					$this->logSuccessFail('0', $query);
				} else {
					$_SESSION['SESS_MSG'] .= msgSuccessFail('fail', "There is some error to upload flag.!!!");
				}
			} else {
				$_SESSION['SESS_MSG'] .= msgSuccessFail('fail', "This files are not allowed for images.!!!");
			}
		}

		$query = "update " . TBL_PROVIDER . " set providerName = '$post[providerName]', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id = '$post[id]'";
		if ($this->executeQry($query)) {
			$this->logSuccessFail('1', $query);
			$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your information has been added successfully");
		}
		else
		$this->logSuccessFail('0', $query);
		#----------for image end---------

		echo "<script>window.location.href='manageProvider.php?page=$post[page]';</script>";
		exit;
	}
        /* delete multiple providers   */
	function deleteAllValues($post) {
		$xmlArr = array();
		$xm = 1;
		if (($post[action] == '')) {
			$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the action or records , And then submit!!!");
			echo "<script language=javascript>window.location.href='manageProvider.php?page=$post[page]&limit=$post[limit]';</script>";
			exit;
		}
		if ($post[action] == 'deleteselected') {
			$delres = $post['chk'];
			$numrec = count($delres);
			if ($numrec > 0) {
				foreach ($delres as $key => $val) {
					$this->executeQry("delete from " . TBL_PROVIDER . " where id = '" . $val . "'");
				}
				$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your all selected information has been deleted successfully!!!");
			} else {
				$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the record!!!");
			}
		}
		if ($post[action] == 'enableall') {
			$delres = $post[chk];
			$numrec = count($delres);
			if ($numrec > 0) {
				foreach ($delres as $key => $val) {
                                    $this->executeQry("update " . TBL_PROVIDER . " set status ='1', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id='$val'");
				}
				$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Enable selected successfully!!!");
			} else {
				$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the record!!!");
			}
		}
		if ($post[action] == 'disableall') {
			$delres = $post[chk];
			$numrec = count($delres);
			if ($numrec > 0) {
				foreach ($delres as $key => $val) {
					$this->executeQry("update " . TBL_PROVIDER . " set status ='0', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id='$val'");

					$xmlArr[$xm]['query'] = addslashes($sql);
					$xmlArr[$xm]['identification'] = $val;
					$xmlArr[$xm]['section'] = "update";
					$xm++;
				}
				$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Disable selected successfully!!!");
			} else {
				$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the record!!!");
			}
		}
		// $xmlInfoObj = new XmlInfo();
		// $xmlInfoObj->addXmlData($xmlArr);
		echo "<script language=javascript>window.location.href='manageProvider.php?page=$post[page]';</script>";
	}
        /* return a provider details   */
	function getResult($id) {
		$sql = $this->executeQry("select * from " . TBL_PROVIDER . " where id = '$id'");
		$num = $this->getTotalRow($sql);
		if ($num > 0) {
			return $line = $this->getResultObject($sql);
		} else {
			redirect("manageProvider.php");
		}
	}
/* return a provider details   */
	function getProvider($id) {
		$sql = $this->executeQry("select c.* from " . TBL_PROVIDER . " as c WHERE c.id = '$id'");
		if ($this->getTotalRow($sql) > 0) {
			return $line = $this->getResultObject($sql);
		} else {
			redirect("manageProvider.php");
		}
	}

/* check provider exists or not  */

	function isProviderNameExist($catname) {
		$query = "select tp.ProviderName from " . TBL_PROVIDER . " as tp where tp.ProviderName='" . trim($catname) . "'";
		$sql = $this->executeQry($query);
		$line = $this->fetch_object($sql);
		if ($this->num_rows($sql) > 0) {
			return 1;
		} else {
			return 0;
		}
	}
        /* perform multiselect for checkboxes  */
	function checkMultipleSelect($posArray, $value) {
		foreach ($posArray as $catid) {
			if ($catid == $value) {
				$sel = 'selected=selected';
				echo $sel;
			}
		}
	}

}

// End Class
?>
