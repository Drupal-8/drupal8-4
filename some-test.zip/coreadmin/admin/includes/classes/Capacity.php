<?php

session_start();

class Capacity extends MySqlDriver {

	function __construct() {
		$this->obj = new MySqlDriver;
	}
// Display all capacity details in manage Capacity module
	function view() {
		$menuObj = new Menu;
		$cond = " 1=1 ";
		if ($_REQUEST['searchtxt'] && $_REQUEST['searchtxt'] != SEARCHTEXT) {
			$searchtxt = trim($_REQUEST['searchtxt']);
			$cond .= " AND capacity LIKE '%$searchtxt%'";
		}
		$query = "select * from " . TBL_CAPACITY . " where" . $cond;
		$sql = $this->executeQry($query);
		$num = $this->getTotalRow($sql);
		$page = $_REQUEST['page'] ? $_REQUEST['page'] : 1;
		if ($num > 0) {
			//-------------------------Paging------------------------------------------------
			$paging = $this->paging($query);
			$this->setLimit($_GET[limit]);
			$recordsPerPage = $this->getLimit();
			$offset = $this->getOffset($_GET["page"]);
			$this->setStyle("redheading");
			$this->setActiveStyle("smallheading");
			$this->setButtonStyle("boldcolor");
			$currQueryString = $this->getQueryString();
			$this->setParameter($currQueryString);
			$totalrecords = $this->numrows;
			$currpage = $this->getPage();
			$totalpage = $this->getNoOfPages();
			$pagenumbers = $this->getPageNo();
			//-------------------------Paging------------------------------------------------
			$orderby = $_GET[orderby] ? $_GET[orderby] : "capacity";
			$order = $_GET[order] ? $_GET[order] : "asc";
			$query .= " ORDER BY $orderby $order LIMIT " . $offset . ", " . $recordsPerPage;
			$rst = $this->executeQry($query);
			$row = $this->getTotalRow($rst);
			if ($row > 0) {
				$i = 1;
				while ($line = $this->getResultObject($rst)) {
					$highlight = $i % 2 == 0 ? "main-body-bynic" : "main-body-bynic2";
					$div_id = "status" . $line->id;
					if ($line->status == 0)
					$status = "InActive";
					else if ($line->status == 1)
					$status = "Active";

					if (strlen($line->description) > 10) {
						$description = stripcslashes(substr($line->description, 0, 10)) . "...";
					} else {
						$description = stripcslashes(substr($line->description, 0, 10));
					}

					$genTable .= '<tr>
                    <th><input name="chk[]" value="' . $line->id . '" type="checkbox" class="checkbox"></th>
                    <td>' . $i . '</td>                    
                    <td>' . stripcslashes($line->capacity) . '</td>
                    <td><div id="' . $div_id . '" style="cursor:pointer;" onClick="javascript:changeStatus(\'' . $div_id . '\',\'' . $line->id . '\',\'managecapacity\')">' . $status . '</div></td>
									<td>';
					$genTable .= '<a  rel="shadowbox;width=705;height=490" title="' . stripslashes($line->productName) . '" href="viewCapacity.php?id=' . base64_encode($line->id) . '"><img src="images/view.png" alt="View" width="16" height="16" border="0" /></a>';
					$genTable .= '</td><td>';
					if ($menuObj->checkEditPermission()) {
						$genTable .= '<a class="i_pencil edit"  href="editCapacity.php?id=' . base64_encode($line->id) . '&page=' . $page . '" title="Edit">Edit</a>';
					}
					$genTable .= '</td><td>';
					if ($menuObj->checkDeletePermission()) {
						$genTable .= "<a  class='i_trashcan edit' href='javascript:void(0);'  onClick=\"if(confirm('Are you sure to delete this Resord?')){window.location.href='pass.php?action=managecapacity&type=delete&id=" . $line->id . "&page=$page'}else{}\" >Delete</a>";
					}
					$genTable .= '</td></tr>';
					$i++;
				}
				switch ($recordsPerPage) {
					case 10:
						$sel1 = "selected='selected'";
						break;
					case 20:
						$sel2 = "selected='selected'";
						break;
					case 30:
						$sel3 = "selected='selected'";
						break;
					case $this->numrows:
						$sel4 = "selected='selected'";
						break;
				}
				$currQueryString = $this->getQueryString();
				$limit = basename($_SERVER['PHP_SELF']) . "?" . $currQueryString;
				$genTable.="<div style='overflow:hidden; margin:0px 0px 0px 50px;'><table border='0' width='88%' height='50'>
					 <tr><td align='left' width='300' class='page_info' 'style=margin-left=20px;'>
					 Display <select name='limit' id='limit' onchange='pagelimit(\"$limit\");' class='page_info'>
					 <option value='10' $sel1>10</option>
					 <option value='20' $sel2>20</option>
					 <option value='30' $sel3>30</option> 
					 <option value='" . $totalrecords . "' $sel4>All</option>  
					   </select> Records Per Page
					</td><td align='center' class='page_info'><inputtype='hidden' name='page' value='" . $currpage . "'></td><td class='page_info' align='center' width='200'>Total " . $totalrecords . " records found</td><td width='0' align='right'>" . $pagenumbers . "</td></tr></table></div>";
			}
		} else {
			$genTable = '<div>&nbsp;</div><div class="alert i_access_denied red">Sorry no records found</div>';
		}
		return $genTable;
	}
// Add new capacity 
	public function addRecord($post) {
		$int_capacity=preg_replace("/[^0-9]/","",$_POST['capacity']);
		$res = $this->executeQry("insert into " . TBL_CAPACITY . " (capacity, status,int_cap, addDate, addedBy) values ('" . $_POST['capacity'] . "', '1','".$int_capacity."', '" . date('Y-m-d H:i:s') . "', '" . $_SESSION['ADMIN_ID'] . "')");
		if ($res) {
			$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your information has been added successfully");
		} else {
			$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "Error occured while adding information.");
		}
		header('location:addCapacity.php');
		exit();
	}
// Edit capacity details
	public function editRecord($post) {
		$int_capacity=preg_replace("/[^0-9]/","",$_POST['capacity']);
		$res = $this->executeQry("update " . TBL_CAPACITY . "  set capacity = '" . $_POST['capacity'] . "',int_cap='".$int_capacity."', moddate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id = '".$post['id']."'");
		if ($res) {
			$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your information has been updated successfully");
		} else {
			$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "Error occured while updating information.");
		}
		header('location:manageCapacity.php');
		exit();
	}
// Changes the status of capacity
	public function changeStatus($get) {
		$status = $this->fetchValue(TBL_CAPACITY, "status", "1 and id = '$get[id]'");
		if ($status == 1) {
			$stat = 0;
			$status = "Inactive, 0";
		} else {
			$stat = 1;
			$status = "Active, 1";
		}

		$query = "update " . TBL_CAPACITY . " set status = '$stat', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id = '$get[id]'";
		if ($this->executeQry($query))
		$this->logSuccessFail('1', $query);
		else
		$this->logSuccessFail('0', $query);
		echo $status;
		exit;
	}
// Delete the specific capacity
	public function deleteRecord($get) {
		$res = $this->executeQry("delete from " . TBL_CAPACITY . " where id = '" . $get['id'] . "'");
		if ($res) {
			$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your Information has been deleted successfully");
		}
		echo "<script language=javascript>window.location.href='manageCapacity.php?page=$get[page]&limit=$get[limit]';</script>";
	}
// delete multiple capacity
	public function deleteAllValues($post) {
		if(($post[action] == '')) {
			$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the action or records , And then submit!!!");
			echo "<script language=javascript>window.location.href='manageCategory.php?cid=$post[cid]&page=$post[page]&limit=$post[limit]';</script>";
			exit;
		}
		if ($post[action] == 'deleteselected') {
			$delres = $post['chk'];
			$numrec = count($delres);
			if ($numrec > 0) {
				foreach ($delres as $key => $val) {
					$this->executeQry("delete from " . TBL_CAPACITY . " where id = '" . $val . "'");
				}
				$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Your all selected information has been deleted successfully!!!");
			} else {
				$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the record!!!");
			}
		}
		if ($post[action] == 'enableall') {
			$delres = $post[chk];
			$numrec = count($delres);
			if ($numrec > 0) {
				foreach ($delres as $key => $val) {
					mysql_query("update " . TBL_CAPACITY . " set status ='1', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id='$val'");
				}
				$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Enable selected successfully!!!");
			} else {
				$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the record!!!");
			}
		}
		if ($post[action] == 'disableall') {
			$delres = $post[chk];
			$numrec = count($delres);
			if ($numrec > 0) {
				foreach ($delres as $key => $val) {
					mysql_query("update " . TBL_CAPACITY . " set status ='0', modDate = '" . date('Y-m-d H:i:s') . "', modBy = '" . $_SESSION['ADMIN_ID'] . "' where id='$val'");
				}
				$_SESSION['SESS_MSG'] = msgSuccessFail("success", "Disable selected successfully!!!");
			} else {
				$_SESSION['SESS_MSG'] = msgSuccessFail("fail", "First select the record!!!");
			}
		}
		echo "<script language=javascript>window.location.href='manageCapacity.php?page=$post[page]';</script>";
	}
 //return Capacity Details
	function getCapacity($id) {
		$sql = $this->executeQry("select c.capacity from ".TBL_CAPACITY . " as c where c.id = '$id'");
		if ($this->getTotalRow($sql) > 0) {
			return $line = $this->getResultObject($sql);
		} else {
			redirect("manageCapacity.php");
		}
	}
}

// End Class
?>
