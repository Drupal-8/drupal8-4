<!-- Google Font and style definitions -->
<link
	rel="stylesheet"
	href="http://fonts.googleapis.com/css?family=PT+Sans:regular,bold">
<link rel="stylesheet"
	href="css/style/style.css">

<!-- include the skins (change to dark if you like) -->
<link
	rel="stylesheet" href="css/style/light/theme.css" id="themestyle">
<!-- <link rel="stylesheet" href="style/dark/theme.css" class="theme"> -->

<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<link rel="stylesheet" href="css/ie.css">
	<![endif]-->
