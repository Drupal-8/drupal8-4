<script type="text/javascript">
	function mainmenu(){
	$(" #nav ul ").css({display: "none"});
		$(" #nav li").click(function(){
		$(this).find('ul:first:hidden').css({visibility: "visible",display: "none"}).slideDown('fast').show();
		},function(){
			$(this).find('ul:first:hidden').css({display: "none"}).slideUp('slow');
		});
		$(" #nav li").hover(function(){
			$(this).find('ul:first:hidden').css({visibility: "visible",display: "none"}).slideDown('fast').show();
			},function(){
				$(this).find('ul:first').slideUp('slow');
			});			
	}
	$(document).ready(function(){
		mainmenu();
});
</script>
<script src="js/jquery_ajax.js"></script>

<div id="pageoptions" style="height: 20px;">
<?php
$genTable="";
$genTable.='<ul>';
$genTable.='<li><a href="logout.php">Logout</a></li>';

$genTable.='<li>you last logged in: '.$_SESSION['ADMIN_LAST_LOGIN'].'&nbsp;</li>';
$genTable.='<li style="float:left"><a href="../" class="active" target="_BLANK">View Site ('.SITENAME.')</a></li>';

$genTable.='</ul>';
echo $genTable;
?>
<?

?>

</div>

<header>
<div id="logo">
	<a href="adminArea.php"><?=__SITENAME__?> </a>
</div>
<div id="header"></div>
<ul class="top-admin">
	<li class="face">Hello</li>
	<li class="admn"><b><?=$_SESSION['ADMINNNAME']?> </b></li>
</ul>

</header>
<nav><?php
    
        $menuClass = new Menu;
        $menuData = $menuClass->displayMenu_new();
   
    ?>  </nav>
<div class="breadcrum-top"></div>
