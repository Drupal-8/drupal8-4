<?php
function __autoload($class_name) {
	$file =  'includes/classes/'.$class_name . '.php';
	if(file_exists($file)) 	require_once($file);
	else die('File Not Found');
}


function checkImgAvailable($image)
{
	$imagePath = ABSOLUTEPATH.$image;
	if(file_exists($imagePath))
	return SITE_URL.$image;
	else
	return NOIMAGE;
}

function redirect($page)
{
	if(!headers_sent()) header("location:$page");
	else  echo "<script>window.location.href='$page'</script>";
}

function unsets($post,$unset_value){
	if(!is_array($unset_value)){$temp=$unset_value;$unset_value=array($temp);}
	if(!empty($post) && !empty($unset_value)){
		foreach($unset_value as $val){
			if(isset($post[$val])){
				unset($post[$val]);
			}
		}
	}
	return $post;
}

function postwithoutspace($post)
{
	foreach($post as $key=>$value)
	{
		if(is_array($value)){
			//print_r($value);
			foreach($value as $key1 => $value1){
				$value1= htmlspecialchars(mysql_real_escape_string(trim($value1)));
				$post[$key1]= $value1;
			}
		}else{
			$value= htmlspecialchars(mysql_real_escape_string(trim($value)));
			$post[$key]= $value;
		}
	}
	return  $post;
}

function displayWithStripslashes($post)
{
	foreach($post as $key=>$value)
	{
		$value=stripslashes(trim($value));
		$post[$key]= $value;
	}
	return  $post;
}

function datediff($date1,$date2,$format='d'){
	$difference = abs(strtotime($date2) - strtotime($date1));
	switch (strtolower($format)){
		case 'd':
			$days = round((($difference/60)/60)/24,0);
			break;
		case 'm':
			$days = round(((($difference/60)/60)/24)/30,0);
			break;
		case 'y':
			$days = round(((($difference/60)/60)/24)/365,0);
			break;
	}
	return $days;
}

// function msgSuccessFail($type,$msg){
// 	if($type == 'fail'){
// 		$preTable = "<table class='Error-Msg' align='center' cellpadding='0' cellspacing='0'><tr><td width='410px' align='center' valign='middle' height='15'><img src='images/error.png' width='16' border='0' height='16'>&nbsp;&nbsp;&nbsp;$msg</td></tr></table>";
// 	} elseif($type == 'success') {
// 		$preTable = "<table class='Success-Msg' align='center' cellpadding='0' cellspacing='0'><tr><td width='410px' align='center' height='15'><img src='images/done.gif' width='16' border='0' height='16'>&nbsp;&nbsp;&nbsp;$msg</td></tr></table>";
// 	}
// 	return $preTable;
// }

function msgSuccessFail($type,$msg){
	if($type == 'fail'){
		$preTable = " <div class='alert i_access_denied red'>$msg </div>";
	} else if($type == 'success') {
		$preTable = "<div class='alert success'>$msg</div>";
	}
	return $preTable;
}

function orderBy($pageurl,$orderby,$displayTitle){
	if($_GET[order] == 'ASC') {
		$order = "DESC";}
		else{ $order = "ASC";}
		if(($_GET[orderby] == $orderby)&&($_GET[order] == 'ASC')){
			$img = "<img src='images/orderup.png' border='0' />";
		}
		elseif(($_GET[orderby] == $orderby)&&($_GET[order] == 'DESC')){
			$img = "<img src='images/orderdown.png'  border='0' />";
		}else{
			$img = "";
		}
		$explodedlink = explode("?",$pageurl);
		if($explodedlink[1]){
			$display = "<a href='$pageurl&orderby=$orderby&order=$order&page=$_GET[page]&limit=$_GET[limit]' class='order'>$displayTitle </a> $img";
		}else{
			$display = "<a href='$pageurl?orderby=$orderby&order=$order&page=$_GET[page]&limit=$_GET[limit]' class='order'>$displayTitle</a> $img";
		}
		echo $display;
}

function findexts($filename) {
	$filename = strtolower($filename);
	$exts = @split("[/\\.]", $filename);
	$n = count($exts)-1;
	$exts = $exts[$n];
	return $exts;
}

function getPageName() {
	$pageName = basename($_SERVER['PHP_SELF']);
	if ($pageName == '') $pageName = "index.php";
	return $pageName;
}

function getImagePath($mainImage,$mainWidth,$mainHeight,$noImage,$noImageWidth,$noImageHeight) {
	//echo file_exists($mainImage);
	$imageDetail = array();
	if(file_exists($mainImage)) {
		array_push($imageDetail,$mainImage);
		array_push($imageDetail,$mainWidth);
		array_push($imageDetail,$mainHeight);
	} elseif(!file_exists($mainImage)) {
		array_push($imageDetail,$noImage);
		array_push($imageDetail,$noImageWidth);
		array_push($imageDetail,$noImageHeight);
	}
	return $imageDetail;
}
if($_SESSION[DEFAULTCURRENCYID] == ''){
	$_SESSION[DEFAULTCURRENCYID]=1;
}

function headContent() {
	$charset="utf-8";
	//require_once (__BASE_DIR_ADMIN__."languages/".$_SESSION['DEFAULTLANGUAGE'].".inc.php");
	$headcontent .= '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head><meta http-equiv="Content-Type" content="text/html; charset='.$charset.'" />';
	$headcontent .=	'<title>Welcome To '.SITENAME.' Admin Panel</title>';
	$headcontent .=	'<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Sans:regular,bold">';
	$headcontent .=	'<link rel="stylesheet" href="css/main/style.css">';

	// include the skins (change to dark if you like) =>===<link rel="stylesheet" href="css/dark/theme.css" class="theme">
	//getjsconstant();
	$headcontent .=	'<link rel="stylesheet" href="css/light/theme.css" id="themestyle">';
	$headcontent .=	'<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<link rel="stylesheet" href="css/ie.css">
	<![endif]-->';
	$headcontent .=	'<script src="js/jquery.min.js"></script>';
	$headcontent .=	'<script src="js/jquery-ui.min.js"></script>';
	$headcontent .='<SCRIPT src="js/ajax.js" language="javascript" type="text/javascript"></SCRIPT>';
	$a=strrpos(getPageName(),"manage");
	if($a===false)	$headcontent .='';
	else $headcontent .='<SCRIPT src="js/perpage.js" language="javascript" type="text/javascript"></SCRIPT>';

	//Top Pageoptions===========================
	$headcontent .="<script>
						$(document).ready(function(){
						$('#wl_config').click(function(){
							var pageoptions = $('#pageoptions');
							if(pageoptions.height() < 250){
								pageoptions.animate({'height':250});
								$(this).addClass('active');
							}else{
								pageoptions.animate({'height':20});
								$(this).removeClass('active');
							}
							return false;
						});
						})
					</script>";
	echo $headcontent;
	/*echo "<pre>";
	 print_r($_SESSION);
	 echo "</pre>";*/
}

// function getjsconstant(){
//
// $tbjs= '<script type="text/javascript">
// var PLEASE_ENTER_NUMERIC_VALUE="'.LANG_PLEASE_ENTER_NUMERIC_VALUE.'";
// var PLEASE_ENTER_VALID_EMAIL_ADDRESS="'.LANG_PLEASE_ENTER_VALID_EMAIL_ADDRESS.'";
// var DATE_IS_NOT_IN_A_VALID_FORMAT="'.LANG_DATE_IS_NOT_IN_A_VALID_FORMAT.'";
// var MONTH_MUST_BE_BETWEEN_1_AND_12="'.LANG_MONTH_MUST_BE_BETWEEN_1_AND_12.'";
// var PLEASE_SELECT_ATLEAST_ONE_RECORD_TO_DELETE="'.LANG_PLEASE_SELECT_ATLEAST_ONE_RECORD_TO_DELETE.'";
// var ARE_YOU_SURE_TO_DELETE_THE_SELECTED_RECORDS="'.LANG_ARE_YOU_SURE_TO_DELETE_THE_SELECTED_RECORDS.'";
// var PLEASE_ENTER_THE="'.LANG_PLEASE_ENTER_THE.'";
// var PLEASE_SELECT_THE="'.LANG_PLEASE_SELECT_THE.'";
// var PLEASE_BROWSE_THE="'.LANG_PLEASE_BROWSE_THE.'";
// var PLEASE_UPLOAD_ONLY_ICO_FILE="'.LANG_PLEASE_UPLOAD_ONLY_ICO_FILE.'";
// var BANNER_IMAGE_WIDTH_SHOULD_NOT_BE_GREATER_THAN="'.LANG_BANNER_IMAGE_WIDTH_SHOULD_NOT_BE_GREATER_THAN.'";
// var PLEASE_ENTER_THE_FOLLOWING_FIELDS="'.LANG_PLEASE_ENTER_THE_FOLLOWING_FIELDS.'";
// var PLEASE_ENTER_SELECT_THE_FOLLOWING_FIELDS="'.LANG_PLEASE_ENTER_SELECT_THE_FOLLOWING_FIELDS.'";
// var PLEASE_SELECT_AN_PACKAGE="'.PLEASE_SELECT_AN_PACKAGE.'";
// var PLEASE_ENTER_USERNAME="'.LANG_PLEASE_ENTER_USERNAME.'";
// var PLEASE_ENTER_EMAIL_ID="'.LANG_PLEASE_ENTER_EMAIL_ID.'";
// var PLEASE_ENTER_PASSWORD="'.LANG_PLEASE_ENTER_PASSWORD.'";
// var IT_SHOULD_ATLEAST_6_CHARACTERS="'.LANG_IT_SHOULD_ATLEAST_6_CHARACTERS.'";
// var PLEASE_ENTER_CATEGORY_NAME="'.LANG_PLEASE_ENTER_CATEGORY_NAME.'";
// var PLEASE_ENTER_VALID_PASSWORD="'.LANG_PLEASE_ENTER_VALID_PASSWORD.'";
//
//
// </script>';
//
// return $tbjs;
//
//
// }
?>
