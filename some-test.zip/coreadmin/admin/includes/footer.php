<footer>
<?=stripslashes('&copy;copyright by '.__SITENAME__)?></footer>
</body>
</html>
