<?php
ob_start();
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();

$tempObj = new Template();
$result = $tempObj->getAllAdmin();

echo headcontent();
?>

</head>
<body>
    <?php include('includes/header.php'); ?>
    <section id="content">
        <h1>Get LayOut</h1>
        <fieldset>

            <form name="frmUser" id="frmUser" method="post">

                <fieldset>

                    <section> <label for="templateName">Select Template</label>
                        <div>
                            <?php echo $tempObj->getAllTemplates($_POST['template']); ?>
                            <div id="chk_templateName"><?php echo $arr_error['template']; ?></div>
                        </div>
                    </section>


                </fieldset>
                <section>
                    <div style="width: 100%;text-align: center;">
                        <button type="submit" name="submit">Submit</button>
                        <!--<button type="button" name="back" onClick="hrefBack()" id="back">Back</button>-->
                    </div>
                </section>
                <?php
                if (isset($_POST['submit'])) { ?>
                <table class="documentation">
                    <tr>
                    <thead>
                    <th>SL.No</th>
                    <th>Title</th>
                    <th>view</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </thead>
                    </tr>	 
                    <?php echo $tempObj->allLayoutDetailsInformation($_POST['template']); ?>
                </table>
                    
            <?php    }
                ?>

            </form>
        </fieldset>
    </section>






