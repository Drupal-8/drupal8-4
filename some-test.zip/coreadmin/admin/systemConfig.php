<?
session_start();
require_once('config/configure.php');
require_once('includes/function/autoload.php');
$loginObj = new Login();
$loginObj->checkSession();
$pageName = getPageName();
$menuObj = new Menu();
$menuObj->checkPermission();

$genObj = new GeneralFunctions();
$sysObj = new SystemConfig();

if (isset($_POST['submit'])) {
    $sysObj->addConfiguration($_POST, $_FILES);
}
?>

<?= headcontent() ?>
<script
language="javascript" src="js/requiredValidation.js"></script>
<script
src="js/file/jquery.filestyle.js"></script>
<!--				Color Picker (START)		-->

<link
    rel="stylesheet" href="colorpicker/js_color_picker_v2.css"
    media="screen">
<script
src="colorpicker/color_functions.js"></script>
<script
type="text/javascript" src="colorpicker/js_color_picker_v2.js"></script>
<!--				Color Picker (END)			-->
<script type="text/javascript">
    function show_value(){
        var sum1 = document.configUser.Allow_user_to_show_identification.length;
        for (var i=0; i < sum1; i++) {
            if (document.configUser.Allow_user_to_show_identification[0].checked)
                document.getElementById("ident").style.display='';
            if (document.configUser.Allow_user_to_show_identification[1].checked)
                document.getElementById("ident").style.display='none';
			   
        }
    }
</script>
</head>
<body onload="show_value();">
    <? include('includes/header.php'); ?>
    <section id="content">
        <h1>System Config Settings</h1>
        <fieldset>
            <form name="configUser" id="configUser" method="post"
                  onSubmit="javascript: return validateFrm(this);"
                  enctype="multipart/form-data">
                      <?
                      echo $_SESSION['SESS_MSG'];
                      unset($_SESSION['SESS_MSG']);
                      ?>

                <fieldset>
                    <label>General Configuration</label>
                    <section> <label>Site Name</label>
                        <div>
                            <input type="text" name="SITE_NAME" id="SITE_NAME"
                                   value="<?= stripslashes($sysObj->fetchValue(TBL_SYSTEMCONFIG, "systemVal", "1 and systemName = 'SITE_NAME'")) ?>"
                                   class="wel" />
                        </div>
                    </section>
                    <section> <label>Site Url</label>
                        <div>
                            <input type="text" name="SITE_URL" id="SITE_URL"
                                   value="<?= stripslashes($sysObj->fetchValue(TBL_SYSTEMCONFIG, "systemVal", "1 and systemName = 'SITE_URL'")) ?>"
                                   class="wel" />
                        </div>
                    </section>

                    <section> <label>Site Email</label>
                        <div>
                            <input name="SITE_EMAIL" id="SITE_EMAIL" type="text"
                                   value="<?= stripslashes($sysObj->fetchValue(TBL_SYSTEMCONFIG, "systemVal", "1 and systemName = 'SITE_EMAIL'")) ?>"
                                   class="wel" />
                        </div>
                    </section>
                    <section> <label>Image Extension Allowed</label>
                        <div>
                            <input name="IMAGE_EXTENSION" type="text"
                                   value="<?= $sysObj->fetchValue(TBL_SYSTEMCONFIG, "systemVal", "1 and systemName ='IMAGE_EXTENSION'") ?>"
                                   class="wel" />
                        </div>
                    </section>
                </fieldset>			


                <div class="main-body-sub"
                     style="text-align: center; margin-left: 0px">
                    <button type="submit" name="submit">Submit</button>
                </div>
                <div id="divTemp" style="display: none;"></div>
            </form>
        </fieldset>
    </section>
    <div id="divTemp" style="display: none;"></div>
</body>
</html>
