<?php

$array = array();

$array = array("AirDev/layout-1" => array(
        "Headers" => array(0 => array(
                "url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/header.html",
                "height" => "497",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/header-template.png"
            )
        ), //close Headers
        "ContentSections" => array(0 => array(
                "url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"),
            1 => array("url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"),
            2 => array("url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"),
            3 => array("url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"),
            4 => array("url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"),
            5 => array("url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"),
        ), // close ContentSections 
        "Footer" => array(0 => array(
                "url" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/section-1.html",
                "height" => "696",
                "thumbnail" => "http://norefresh.thesparxitsolutions.com/EmailThemeBuilder_Ram/templates/AirDev/layout-1/template/section-01.png"
            )
        )
    ) // close AirDev/layout-1  of 1 index 
); // close Main array

echo "<pre>";

print_r($array);
echo "</pre>";
echo json_encode($array);


